import { geocodeLabel, geocodeUpdates } from './lib/geocode-results.js';
import { PASSWORD_UPDATED } from './lib/password-reset.js';
import { ROUTE_STOP_LIMIT, pickRouteStops, routeToggleLabel, visibleRoutePool } from './lib/route-picks.js';
import { ROUTE_TRAY_KEY, routeTrayCollapsedByDefault, routeTraySummary, shouldExpandRouteTray } from './lib/route-tray.js';
import { MAP_FACTS } from './lib/map-facts.js';
import { ARRIVAL_METERS, NAV_CHOICE_KEY, appleDirectionsUrl, arrivedAtStop, etaSeconds, googleDirectionsUrl, googleTravelMode, isAppleDevice, metersBetween, osrmProfile, readNavChoice } from './lib/route-nav.js';
import { acquireScreenWakeLock, activeStep, arrowRotationDegrees, bearingDegrees, chooseTravelHeading, compassHeadingFromOrientation, createGpsFilter, createInterpolator, createReadoutThrottle, createRerouteGate, lineLatLngs, maneuverText, navLookaheadPixels, navZoomFor, normalizeSteps, offsetCameraPoint, pointAlong, releaseScreenWakeLock, requestCompassPermission, smoothBearing, snapToRoute, splitRoute } from './lib/nav-motion.js';
import { installMapBearing, setMapHeading } from './lib/map-bearing.js';
import { createArrayCursor, leadCacheUsable, localStamp, mergeLeadDelta, newestUpdatedAt, nextObjectEnd, normalizeStamp, parseJsonArraySlice, planLeadSync, takeCompleteObjects } from './lib/lead-cache.js';
import { clearLeadCache, leadCacheScope, readLeadCache, writeLeadCache } from './lib/lead-store.js';
import { LEAD_OVERLAY_COLUMNS, LEAD_OVERLAY_OR, STATIC_LEAD_SOURCES, mergeLeadOverlay, pageRanges } from './lib/lead-sync.js';
import { STREET_ZOOM, clusterLeads, pinDiff, sampleHeat } from './lib/pin-layer.js';
import { HAIL_MILES, WARNING_COLORS, housesInStorm, readStormCache, reportMarkerText, writeStormCache } from './lib/storm-maps.js';
import { readSavedLayers, resolveLayers, writeSavedLayers } from './lib/map-layers.js';
import { bindAreaDraw } from './area-draw.js';
import { roleLabel } from './lib/field-rules.js';
import { MANAGEMENT_LINKS, canOpenManagement, managementProfile } from './lib/account-rules.js';
import { forgetRole, rememberRole } from './lib/management-gate.js';
import { assertHandoffPhoto, handoffPermissions, isHandoffSetter, validateHandoffPatch, visibleHandoffs } from './lib/handoff-access.js';
import { canSeeReceipt, canUploadReceipt } from './lib/receipt-access.js';
import { createDeferredAuthHandler } from './lib/auth-events.js';

const STATUS_OPTIONS=['New','Knocked','No Answer','Interested','Appointment','Not Interested','Do Not Knock'];
const DOOR_STATUSES=['Knocked','No Answer','Interested','Not Interested','Do Not Knock'].filter(s=>STATUS_OPTIONS.includes(s));
const doorSheetMedia=window.matchMedia('(max-width: 960px)');
const HOME_BASE={lat:40.3931,lng:-82.4857};
const HOME_MILES=35;
const LIST_SNAPS=['sheet-collapsed','sheet-half','sheet-full'];
const APPOINTMENT_STAGES=['Scheduled','Confirmed','Completed','No-show','Cancelled'];
const LOCAL_KEY='tnrc2:local';

const state={
  mode:'local', supabase:null, session:null, user:null, currentRep:null,
  leads:[], filtered:[], reps:[], territories:[], appointments:[], activities:[], centers:{},
  selected:new Set(), active:null, map:null, markerLayer:null, heatLayers:[], stormLayer:null,
  stormPack:null, stormHouseIds:null, stormToken:0, radarLayers:[], radarTimer:null, radarSignature:'', warningLayer:null, warningSignature:'', reportLayer:null, reportSignature:'',
  routeLine:null, userMarker:null, routeStops:[], currentLocation:null,
  filters:{q:'',status:'',rep:'',territory:'',source:'',mine:false},
  layerFlags:{pins:true,density:false,opportunity:false,roofAge:false,radar:false,warnings:false,reports:false,territories:false},
  routeMode:'driving', busy:false, config:null, realtimeChannel:null, refreshTimer:null,
  doorLeadId:null, doorSaving:false, doorUndo:null,
  homeArea:true, didFit:false, listSnap:'sheet-collapsed', pinBannerDismissed:false,
  listShown:180, listFilterKey:'', listRows:null, listPaintToken:'', listScrollFrame:0, renderQueued:false,
  leadsById:new Map(), pinMarkers:new Map(), pinShown:new Set(), pinRenderer:null, pinClusters:null, clusterSig:'', clusterSource:null, clusterZoom:null,
  heatTimer:null, heatKey:'', territoryKey:'', bootDone:false, stormBusy:false, fieldWarmed:false, listSortToken:0,
  navigating:false, navIndex:0, navFollow:true, navWatch:null, navPrompted:'', navLegStop:'', navLegFrom:null, routeGeometry:null, navLayers:[],
  pendingPostSignIn:false, paintTicket:0, toolsDeferred:false, pinsMarked:false, cloudReady:false, staticPromise:null,
  tileLayer:null, mapLoaderGen:0, mapSettled:false, pinsPainted:false, awaitingFirstFit:false, factTimer:null, mapLoaderGiveUp:null,
  sessionReady:false, leadLoadSettled:false, cacheScope:''
};

const $=id=>document.getElementById(id);
let areaDraw=null;
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const fmt=n=>Number(n||0).toLocaleString();
const nowISO=()=>new Date().toISOString();
const isCoords=l=>{const lat=Number(l?.lat),lng=Number(l?.lng);return l?.lat!=null&&l?.lng!=null&&Number.isFinite(lat)&&Number.isFinite(lng);};
const leadStatus=l=>l.status||localSaved(l).status||'New';
const leadOwnerName=l=>l.assignedRepName||(state.reps.find(r=>r.id===l.assignedRepId)?.name)||localSaved(l).owner||'';
const localSaved=l=>JSON.parse(localStorage.getItem(`tnrc2:lead:${l.id}`)||'{}');
function saveLocal(l,v){localStorage.setItem(`tnrc2:lead:${l.id}`,JSON.stringify(v));}
function debounce(fn,ms=150){let t;return(...a)=>{clearTimeout(t);t=setTimeout(()=>fn(...a),ms)}}

let cloudToken='';
let cloudFlight=null;
let authEpoch=0;
let weatherApiPromise;
function weatherApi(){ weatherApiPromise ||= import('./weather-widget.js'); return weatherApiPromise; }
function closeWeather(options){ weatherApi().then(mod=>mod.setWeatherOpen(false, options)).catch(()=>{}); }
function deferFieldTools(){
  if(state.toolsDeferred) return;
  state.toolsDeferred=true;
  import('./field-ops.js').catch(()=>{});
  import('./tn-files/password-reset.js').catch(()=>{});
  import('./tn-files/sheet-actions.js').catch(()=>{});
}
function markFirstPins(){
  if(state.pinsMarked) return;
  state.pinsMarked=true;
  window.__tnFirstPins=performance.now();
  document.documentElement.dataset.tnPins='1';
  deferFieldTools();
}


function rememberLeadCache(stamp, leads){
  if(!leadCacheUsable({leads})) return;
  writeLeadCache({stamp, leads, savedAt:Date.now()}, state.cacheScope);
}
async function boot(){
  bindStaticEvents();
  showLogin();
  const centersP=fetchJSON('/data/city-centers.json').catch(()=>({}));
  const cfgP=fetchJSON('/api/config').catch(()=>null);
  const [centers, cfg]=await Promise.all([centersP, cfgP]);
  state.centers=centers||{};
  if(cfg?.configured){
    state.config=cfg;
    try{
      const {createClient}=await import('/vendor/supabase/supabase.js');
      state.supabase=createClient(cfg.url,cfg.publishableKey);
      const {data}=await state.supabase.auth.getSession();
      state.supabase.auth.onAuthStateChange(createDeferredAuthHandler({
        initialSession:data.session,
        onInvalidate(event,session){
          if(event==='SIGNED_OUT' || (state.user && state.user.id!==session?.user?.id)) showLogin();
        },
        onSession:session=>enterCloud(session),
        onError:error=>{console.error(error);showLogin();$('loginError').textContent='Could not load this account. Please sign in again.';}
      }));
      if(data.session) await enterCloud(data.session);
      else showLogin();
    }catch(e){console.error(e);showLogin();$('loginError').textContent=e.message||'Could not verify this account. Please sign in again.';}
  }else{
    enterLocal('Cloud is not configured on this Vercel deployment. Local device mode is active.');
  }
}

async function fetchJSON(url){const r=await fetch(url);if(!r.ok)throw new Error(`HTTP ${r.status}`);return r.json()}

function bindStaticEvents(){
  document.addEventListener('tn-map-panel-view',event=>{
    if(event.detail?.view==='addresses' && useDoorSheet())setListSheet('sheet-half');
    else if(event.detail?.view==='route' && useDoorSheet())setListSheet('sheet-full');
  });
  $('loginForm').addEventListener('submit',login);
  $('logoutBtn').onclick=()=>{ const userId=state.user?.id; showLogin(); forgetRole(localStorage, userId); state.supabase?.auth.signOut(); };
  $('localModeBtn').onclick=()=>{hideLogin();enterLocal('Local device mode enabled. Connect Supabase for shared live team data.')};
  $('nextBtn').onclick=nextBest; $('nextCardBtn').onclick=nextBest;
  $('mobileNext').onclick=nextBest; $('mobileRoute').onclick=openRouteFromChrome; $('mobileLocate').onclick=locate;
  $('routeBtn').onclick=openRouteFromChrome; $('routeTrayBtn').onclick=optimizeAndDrawRoute;
  $('routeTrayToggle').onclick=()=>setRouteTrayCollapsed($('routeTrayToggle').getAttribute('aria-expanded')==='true');
  $('selectVisibleBtn').onclick=selectVisibleForRoute; $('clearRouteBtn').onclick=clearRoute;
  $('doorSheetRoute').onclick=()=>{if(!state.doorLeadId)return;toggleSelected(state.doorLeadId);$('doorSheetRoute').textContent=routeToggleLabel(state.selected.has(state.doorLeadId));};
  $('focusBtn').onclick=toggleMapFocus; $('fitBtn').onclick=fitFilteredLeads;
  $('closeDrawer').onclick=closeDrawer;
  $('closeAdmin').onclick=()=>$('adminModal').classList.add('hidden');
  $('tabHandoffs').onclick=()=>switchTab('handoffs',{toggle:true});
  $('tabTeam').onclick=()=>switchTab('team',{toggle:true});
  $('filterBtn').onclick=()=>setFilterOpen($('filterPanel').hidden);
  $('mapInfoToggle').onclick=()=>setInfoOpen($('mapInfoPanel').hidden);
  $('adminBtn').onclick=(e)=>{ if(canOpenManagement({email:state.user?.email, rep:state.currentRep, adminEmails:state.config?.adminEmails})) return; e.preventDefault(); };
  $('postSignInContinue')?.addEventListener('click', ()=>$('postSignIn').classList.add('hidden'));
  $('locateBtn').onclick=locate;
  const scheduleFilterRender=debounce(()=>{syncFilters();renderAll()},150);
  $('clearBtn').onclick=()=>{['search','statusFilter','repFilter','territoryFilter','sourceFilter'].forEach(id=>$(id).value='');$('mineToggle').checked=false;state.stormHouseIds=null;syncFilters();renderAll()};
  $('search').addEventListener('input',scheduleFilterRender);
  ['statusFilter','repFilter','territoryFilter','sourceFilter'].forEach(id=>$(id).addEventListener('change',scheduleFilterRender));
  $('mineToggle').addEventListener('change',scheduleFilterRender);
  $('workList').addEventListener('scroll',()=>{
    if(state.listScrollFrame)return;
    state.listScrollFrame=requestAnimationFrame(()=>{state.listScrollFrame=0;paintWorkList()});
  });
  $('layerBtn').onclick=()=>setLayersOpen(!$('layerMenu').classList.contains('open'));
  $('legendKey').onclick=()=>{
    const legend=$('mapLegend');
    const open=legend.classList.toggle('isOpen');
    if(open){setFilterOpen(false);setInfoOpen(false);setLayersOpen(false);closeWeather();}
    $('legendKey').setAttribute('aria-expanded',open?'true':'false');
    if(!open||!useDoorSheet()){legend.style.top='';return;}
    const canvas=document.querySelector('.mapCanvas').getBoundingClientRect();
    const overlay=document.querySelector('.mapTopOverlay').getBoundingClientRect();
    legend.style.top=`${Math.round(overlay.bottom-canvas.top+8)}px`;
  };
  document.addEventListener('click',e=>{
    if(!$('layerMenu').contains(e.target)&&!$('layerBtn').contains(e.target))setLayersOpen(false);
    if(!$('mapLegend').contains(e.target)&&e.target!==$('legendKey')){$('mapLegend').classList.remove('isOpen');$('legendKey').setAttribute('aria-expanded','false');}
    if($('filterPanel')&&!$('filterPanel').hidden&&!$('filterPanel').contains(e.target)&&e.target!==$('filterBtn')&&!$('filterBtn').contains(e.target))setFilterOpen(false);
    if($('mapInfoPanel')&&!$('mapInfoPanel').hidden&&!$('mapInfo').contains(e.target))setInfoOpen(false);
  });
  document.addEventListener('tn-close-popovers',e=>{
    if(e.detail!=='layers')setLayersOpen(false);
    if(e.detail!=='filters')setFilterOpen(false);
    if(e.detail!=='info')setInfoOpen(false);
  });
  document.addEventListener('keydown',e=>{
    if(e.key!=='Escape')return;
    const restore=$('layerMenu').contains(document.activeElement)?$('layerBtn'):$('filterPanel').contains(document.activeElement)?$('filterBtn'):$('mapInfoPanel').contains(document.activeElement)?$('mapInfoToggle'):null;
    setLayersOpen(false);
    $('mapLegend').classList.remove('isOpen');
    $('legendKey').setAttribute('aria-expanded','false');
    setFilterOpen(false);
    setInfoOpen(false);
    restore?.focus();
  });
  const savedLayers=readSavedLayers(localStorage);
  const layers=resolveLayers(savedLayers);
  document.querySelectorAll('[data-layer]').forEach(el=>{
    const id=el.dataset.layer;
    if(Object.prototype.hasOwnProperty.call(layers,id))el.checked=layers[id];
    state.layerFlags[id]=!!el.checked;
    el.addEventListener('change',()=>{
      state.layerFlags[id]=el.checked;
      try{writeSavedLayers(localStorage,state.layerFlags);}catch{}
      if(id==='radar'||id==='warnings'||id==='reports')syncStormOverlays();
      else refreshMapLayers();
    });
  });
  areaDraw=bindAreaDraw({
    getMap:()=>state.map,
    getLeads:()=>state.filtered,
    scoreLead,
    getStart:()=>state.currentLocation,
    toast,
    onDrawing(on){
      if(!on)return;
      setFilterOpen(false);
      setInfoOpen(false);
      closeWeather({persist:false});
      setLayersOpen(false);
      if(useDoorSheet())setListSheet('sheet-collapsed');
    },
    onRoute:applyAreaRoute
  });
  $('stormHousesBtn').onclick=housesInStormArea;
  $('routeMode').addEventListener('change',e=>setRouteMode(e.target.value));
  $('trayDrive').onclick=()=>setRouteMode('driving');
  $('trayWalk').onclick=()=>setRouteMode('walking');
  $('startRouteBtn').onclick=startRoute;
  $('navChoiceBtn').onclick=()=>openNavChoice(false);
  $('navInApp').onclick=()=>confirmNavChoice('app');
  $('navGoogle').onclick=()=>confirmNavChoice('google');
  $('navApple').onclick=()=>confirmNavChoice('apple');
  $('navChoiceCancel').onclick=closeNavChoice;
  $('navChoiceClose').onclick=closeNavChoice;
  $('navRecenter').onclick=recenterNav;
  $('navGoogleLeg').onclick=()=>openExternalLeg('google');
  $('navAppleLeg').onclick=()=>openExternalLeg('apple');
  $('navNextStop').onclick=()=>advanceNavStop();
  $('navEnd').onclick=()=>endNavigation('Navigation ended.');
  ensureNavControls();
  document.addEventListener('fullscreenchange', onNavFullscreenChange);
  document.addEventListener('webkitfullscreenchange', onNavFullscreenChange);
  syncNavChoiceButton();
  $('routeCount').addEventListener('input',e=>{$('routeCountValue').textContent=e.target.value;invalidateBuiltRoute();}); $('routeDistance').textContent='';
  $('optimizeRouteBtn').onclick=optimizeAndDrawRoute;
  $('openGoogleRouteBtn').onclick=openGoogleRouteBlocks;
  $('closeRoute').onclick=closeRoutePanel;
  $('adminImportBtn').onclick=importLeadsToCloud;
  $('adminTerritoryBtn').onclick=syncTerritories;
  $('adminGeocodeBtn').onclick=geocodeAll;
  $('adminStormBtn').onclick=loadStorms;
  $('adminExportBtn').onclick=exportLeads;
  $('appointmentForm').addEventListener('submit',saveAppointmentFromForm);
  $('closeAppointment').onclick=()=>$('appointmentModal').classList.add('hidden');
  $('appStage').addEventListener('change',()=>{});
  $('copyHandoffBtn').onclick=copyCurrentHandoff;
  $('completeHandoffBtn')?.addEventListener('click',completeHandoff);
  $('reopenHandoffBtn')?.addEventListener('click',reopenHandoff);
  $('appPhoto')?.addEventListener('change',()=>{const file=$('appPhoto').files?.[0]; if(file) addHandoffPhoto(file);});
  $('saveHandoffReceiptBtn')?.addEventListener('click',()=>uploadReceipt({
    file:$('handoffReceiptFile')?.files?.[0],
    amount:$('handoffReceiptAmount')?.value,
    vendor:$('handoffReceiptVendor')?.value,
    recordDate:$('handoffReceiptDate')?.value,
    note:$('handoffReceiptNote')?.value,
    leadId:$('appLeadId')?.value||null,
    errorEl:$('handoffReceiptError')
  }));
  $('uploadReceiptBtn')?.addEventListener('click',()=>openGeneralReceipt());
  $('receiptForm')?.addEventListener('submit',saveGeneralReceipt);
  $('closeReceipt')?.addEventListener('click',()=>$('receiptModal')?.classList.add('hidden'));
  $('doorSheetClose').onclick=closeDoorSheet;
  $('doorSheetScrim').onclick=closeDoorSheet;
  $('doorSheetFull').onclick=()=>{const id=state.doorLeadId; closeDoorSheet(); if(id) openLead(id,{full:true});};
  $('toastUndo').onclick=undoDoorStatus;
  $('toastNext').onclick=()=>openNextHouse(state.doorUndo?.id);
  $('homeAreaBtn').onclick=()=>setHomeArea(true);
  $('allOhioBtn').onclick=()=>setHomeArea(false);
  $('pinBannerAction').onclick=openAdmin;
  $('pinBannerDismiss').onclick=()=>{state.pinBannerDismissed=true;$('pinBanner').classList.add('hidden');};
  bindDoorSwipe();
  bindListSheet();
  syncListMode();
  rotateMapFacts();
  setRouteTrayCollapsed(readRouteTrayCollapsed(), {persist:false});
  const onDoorMedia=()=>{
    if(state.map){
      closeDoorSheet();
      state.pinMarkers.forEach(marker=>marker.remove());
      state.pinMarkers.clear();
      state.pinShown.clear();
      state.clusterSig='';
      refreshMapLayers();
    }
    syncListMode();
  };
  if(doorSheetMedia.addEventListener) doorSheetMedia.addEventListener('change',onDoorMedia);
  else doorSheetMedia.addListener(onDoorMedia);
}

function enterLocal(message){
  authEpoch++; cloudToken=''; cloudFlight=null;
  if(state.realtimeChannel && state.supabase){
    try{ state.supabase.removeChannel(state.realtimeChannel); }catch{ /* channel may already be closed */ }
  }
  state.realtimeChannel=null;
  state.mode='local'; state.session=null; state.user=null; state.currentRep=null; state.cloudReady=false; state.cacheScope='';
  hideLogin(); state.sessionReady=true; if(!state.map) initMapOnce();
  $('userMenu').classList.add('hidden'); $('adminBtn').classList.add('hidden'); $('adminBtn').hidden = true;
  $('connection').textContent='LOCAL DEVICE'; $('connection').className='chip local';
  $('cloudNotice').textContent=message||'Local mode'; $('cloudNotice').classList.remove('hidden');
  if(!state.bootDone) setBootProgress(0,0);
  const epoch=authEpoch;
  loadLocalDataset().catch(e=>{if(epoch===authEpoch){hideBoot();showFatal(e)}});
}
async function loadLocalDataset(){
  const epoch=authEpoch;
  const current=()=>epoch===authEpoch;
  const manifest=state.staticManifest||await fetchJSON('/data/manifest.json').catch(()=>null);
  if(!current()) return;
  const stamp=localStamp(manifest);
  const meta=JSON.parse(localStorage.getItem('tnrc2:leadsMeta')||'{}');
  state.reps=JSON.parse(localStorage.getItem('tnrc2:reps')||'[]');
  state.territories=JSON.parse(localStorage.getItem('tnrc2:territories')||'[]');
  state.appointments=JSON.parse(localStorage.getItem('tnrc2:appointments')||'[]');
  state.activities=JSON.parse(localStorage.getItem('tnrc2:activities')||'[]');
  const total=manifest?.totalRecords||0;
  $('datasetCount').textContent=total?`${fmt(total)} source records`:'';
  initMapOnce();
  const cached=await readLeadCache(state.cacheScope);
  if(!current()) return;
  if(leadCacheUsable(cached) && cached.stamp===stamp){
    if(!total) $('datasetCount').textContent=`${fmt(cached.leads.length)} source records`;
    if(!state.bootDone) streamLeads(cached.leads, total||cached.leads.length, meta);
    return;
  }
  if(state.staticPromise){
    const leads=await state.staticPromise;
    if(!current()) return;
    if(!leads?.length){ showLeadListPrivate(meta); return; }
    if(!total) $('datasetCount').textContent=`${fmt(leads.length)} source records`;
    if(!state.bootDone) streamLeads(leads, total||leads.length, meta);
    rememberLeadCache(stamp, leads);
    return;
  }
  const response=await fetch('/data/leads.json').catch(()=>null);
  if(!current()) return;
  if(!response?.ok){ showLeadListPrivate(meta); return; }
  if(!response.body?.getReader){
    const text=await response.text();
    if(!current()) return;
    const leads=await ingestLeadText(text, total, meta, current);
    if(!current()) return;
    if(!total) $('datasetCount').textContent=`${fmt(leads.length)} source records`;
    rememberLeadCache(stamp, leads);
    return;
  }
  const leads=await readLeadResponse(response, total, meta, current);
  if(!current()) return;
  if(!total) $('datasetCount').textContent=`${fmt(leads.length)} source records`;
  rememberLeadCache(stamp, leads);
}
// The homeowner list is no longer served as a public static file. A missing
// /data/leads.json resolves to an empty list so cloud mode reads every lead
// from Supabase and local mode shows a sign-in notice instead of crashing.
function showLeadListPrivate(meta){
  $('datasetCount').textContent='';
  $('cloudNotice').textContent='Local mode. The homeowner list is private. Sign in to load houses.';
  $('cloudNotice').classList.remove('hidden');
  if(!state.bootDone) streamLeads([], 0, meta);
}
function startStaticLeads(){
  if(state.staticPromise) return state.staticPromise;
  const epoch=authEpoch;
  const current=()=>epoch===authEpoch;
  state.staticPromise=(async()=>{
    const manifest=await fetchJSON('/data/manifest.json').catch(()=>null);
    state.staticManifest=manifest;
    const total=manifest?.totalRecords||0;
    if(current() && total && $('datasetCount')) $('datasetCount').textContent=`${fmt(total)} source records`;
    const response=await fetch('/data/leads.json').catch(()=>null);
    if(!response?.ok){ state.staticUnavailable=true; return []; }
    if(!response.body?.getReader){
      const text=await response.text();
      return ingestLeadText(text, total, null, current);
    }
    return readLeadResponse(response, total, null, current);
  })().catch(error=>{ console.error(error); state.staticUnavailable=true; return []; });
  return state.staticPromise;
}
async function readLeadResponse(response, total, meta, current=()=>true){
  const reader=response.body.getReader();
  const decoder=new TextDecoder();
  let text='';
  const cursor=createArrayCursor();
  let mark=0;
  const leads=[];
  let accept=!state.bootDone;
  state.stopLeadRead=()=>{ accept=false; };
  const take=(batch, last)=>{
    if(batch.length) leads.push(...batch);
    if(accept && current()) ingestLeadChunk(batch, meta, total||leads.length, last);
  };
  while(true){
    const {done,value}=await reader.read();
    text+=decoder.decode(value||new Uint8Array(), {stream:!done});
    while(true){
      const end=takeCompleteObjects(text, cursor, 400);
      if(end<=mark) break;
      const batch=parseJsonArraySlice(text, mark, end);
      mark=end;
      if(!batch.length) break;
      take(batch, false);
      await new Promise(resolve=>requestAnimationFrame(resolve));
    }
    if(done) break;
  }
  const tail=parseJsonArraySlice(text, mark, text.length);
  take(tail, true);
  return leads;
}
async function ingestLeadText(text, total, meta, current=()=>true){
  if(current()) resetLeadStream();
  const cursor=createArrayCursor();
  const leads=[];
  let mark=0;
  let ingested=false;
  while(mark<text.length){
    const end=nextObjectEnd(text, cursor, 2000);
    if(end===mark) break;
    const last=cursor.i>=text.length;
    const batch=parseJsonArraySlice(text, mark, end);
    mark=end;
    if(!batch.length && !last) continue;
    leads.push(...batch);
    if(current()) ingestLeadChunk(batch, meta, total||leads.length, last);
    ingested=true;
    if(!last) await new Promise(resolve=>requestAnimationFrame(resolve));
  }
  if(!ingested && current()) ingestLeadChunk([], meta, total, true);
  return leads;
}

async function enterCloud(session){
  const token=session?.access_token||'';
  if(!token) return;
  if(token===cloudToken && (cloudFlight || state.cloudReady)) return cloudFlight;
  authEpoch++;
  cloudToken=token;
  state.cloudReady=false;
  if(state.realtimeChannel && state.supabase){
    try{ state.supabase.removeChannel(state.realtimeChannel); }catch{ /* channel may already be closed */ }
  }
  state.realtimeChannel=null;
  const flight=runEnterCloud(session).finally(()=>{ if(cloudFlight===flight) cloudFlight=null; });
  cloudFlight=flight;
  return flight;
}
async function runEnterCloud(session){
  const epoch=authEpoch;
  const verified=await state.supabase.auth.getUser(session.access_token);
  if(epoch!==authEpoch) return;
  if(verified.error || !verified.data?.user?.id) throw new Error('Sign in again to verify this account.');
  const user=verified.data.user;
  const profile=await state.supabase.from('reps').select('id,user_id,name,role,active').eq('user_id',user.id).eq('active',true).maybeSingle();
  if(epoch!==authEpoch) return;
  if(profile.error || !profile.data) throw new Error('An active team profile is required.');
  const gate=await state.supabase.rpc('password_gate_status');
  if(epoch!==authEpoch) return;
  if(gate.error || typeof gate.data?.must_change!=='boolean' || typeof gate.data?.impersonating!=='boolean') throw new Error('Account security verification is unavailable.');
  if(gate.data.must_change && !gate.data.impersonating){document.dispatchEvent(new CustomEvent('tn-password-required'));throw new Error('Choose your own password before opening the field map.');}
  state.cacheScope=leadCacheScope(state.config?.url,user.id);
  state.mode='cloud'; state.session={...session,user}; state.user=user; state.currentRep=profile.data; hideLogin();
  if(epoch!==authEpoch) return;
  state.sessionReady=true;
  if(!state.map) initMapOnce();
  deferFieldTools();
  settleMapLoader(state.mapLoaderGen);
  $('connection').textContent='CLOUD SYNC'; $('connection').className='chip live';
  $('userMenu').classList.remove('hidden');
  $('userIdentity').textContent=session.user.email||session.user.id;
  $('cloudNotice').classList.add('hidden');
  const current=()=>epoch===authEpoch;
  const sideP=loadSideData(current).then(()=>null,error=>error);
  try{
    await loadLeadBundle(current);
    if(epoch!==authEpoch) return;
    const open=canOpenManagement({email:session.user.email, rep:state.currentRep, adminEmails:state.config?.adminEmails});
    $('adminBtn').hidden = !open;
    $('adminBtn').classList.toggle('hidden', !open);
    if(state.user?.id && state.currentRep?.role) rememberRole(localStorage, state.user.id, state.currentRep.role);
    if(state.pendingPostSignIn){state.pendingPostSignIn=false; if(open) showPostSignIn();}
    if(!state.map) initMapOnce();
    startRealtime();
    state.cloudReady=true;
    updatePinBanner();
    const sideError=await sideP;
    if(epoch!==authEpoch) return;
    if(sideError) throw sideError;
    publishSideData();
  }catch(e){
    if(!current()) return;
    console.error(e);
    cloudToken='';
    state.cloudReady=false;
    state.pendingPostSignIn=false;
    showLogin();
    $('loginError').textContent=`Cloud connection failed: ${e.message}`;
  }
}

async function loadCloudData(){
  const epoch=authEpoch;
  const current=()=>epoch===authEpoch && state.mode==='cloud';
  const sideP=loadSideData(current).then(()=>null,error=>error);
  await loadLeadBundle(current);
  const sideError=await sideP;
  if(!current()) return;
  if(sideError) throw sideError;
  publishSideData();
}
async function loadLeadBundle(current=()=>true){
  const sb=state.supabase;
  const [reps, territories, leads]=await Promise.all([
    fetchAll(()=>sb.from('reps').select('id,user_id,name,role,active').eq('active',true).order('name')),
    fetchAll(()=>sb.from('territories').select('*').order('name')),
    loadCloudLeadRows(current)
  ]);
  if(!current()) return;
  state.reps=reps;
  state.currentRep=managementProfile({
    email:state.user?.email,
    rep:state.reps.find(r=>r.user_id===state.user.id)||null,
    userId:state.user?.id,
    name:state.user?.user_metadata?.name||''
  });
  if(!state.currentRep) throw new Error('Your Supabase account is signed in, but no active rep profile exists yet. Add the user to public.reps.');
  state.territories=territories;
  if(leads) replaceLeads(leads);
}
function loadSideData(current=()=>true){
  const sb=state.supabase;
  return Promise.all([
    fetchAll(()=>sb.from('appointments').select('*,canvasser:reps!appointments_canvasser_id_fkey(id,name),salesperson:reps!appointments_salesperson_id_fkey(id,name)').order('scheduled_at',{ascending:true})),
    fetchAll(()=>sb.from('lead_activity').select('id,lead_id,actor_id,action,metadata,created_at,actor:reps!lead_activity_actor_id_fkey(name)').order('created_at',{ascending:false}).limit(3000))
  ]).then(([appointments, activities])=>{
    if(!current()) return;
    state.appointments=appointments;
    state.activities=activities;
  });
}
function publishSideData(){
  if(!state.bootDone) return;
  renderStats();
  renderHandoffs();
  renderTeam();
  renderSidebarCounts();
  state.listPaintToken='';
  paintWorkList();
}
async function loadCloudLeadRows(current=()=>true){
  const sb=state.supabase;
  const raw=await readLeadCache(state.cacheScope);
  const cached=leadCacheUsable(raw)?raw:null;
  const cachedLeads=cached?.leads||[];
  let boot=null;
  try{
    const rpc=await sb.rpc('lead_map_boot');
    if(!rpc.error && rpc.data) boot=typeof rpc.data==='string'?JSON.parse(rpc.data):rpc.data;
  }catch{ boot=null; }
  let remoteCount=boot&&boot.count!=null?Number(boot.count):null;
  let remoteUpdatedAt=boot?normalizeStamp(boot.newest):'';
  if(!boot){
    try{
      const [countQuery, newest]=await Promise.all([
        sb.from('leads').select('id',{count:'exact',head:true}),
        sb.from('leads').select('updated_at').order('updated_at',{ascending:false}).limit(1)
      ]);
      if(!countQuery.error) remoteCount=countQuery.count;
      remoteUpdatedAt=normalizeStamp(newest.data?.[0]?.updated_at||'');
    }catch{/* a failed stamp check falls through to a full read */}
  }
  const plan=planLeadSync({cachedStamp:normalizeStamp(cached?.stamp||''), cachedCount:cachedLeads.length, remoteCount, remoteUpdatedAt});
  if(plan==='use-cache') return cachedLeads.map(normalizeLead);
  if(plan==='delta'){
    const since=cached.stamp;
    const head=await sb.from('leads').select('id',{count:'exact',head:true}).gt('updated_at', since);
    if(head.error) throw head.error;
    // A missing/empty count cannot certify a cache older than the remote stamp.
    // Reload instead of marking stale rows as current and skipping them next time.
    if(!Number.isSafeInteger(head.count) || head.count<=0) return loadColdLeads(sb, boot, remoteCount, remoteUpdatedAt, current);
    const delta=await fetchAllParallel(()=>sb.from('leads').select('*').gt('updated_at', since).order('updated_at'), head.count);
    const merged=mergeLeadDelta(cachedLeads, delta).map(normalizeLead);
    const stamp=remoteUpdatedAt||normalizeStamp(newestUpdatedAt(merged));
    if(current()) rememberLeadCache(stamp, merged);
    return merged;
  }
  return loadColdLeads(sb, boot, remoteCount, remoteUpdatedAt, current);
}
async function loadColdLeads(sb, boot, remoteCount, remoteUpdatedAt, current=()=>true){
  const basePromise=state.staticPromise||startStaticLeads();
  let overlay=Array.isArray(boot?.overlay)?boot.overlay:null;
  let added=Array.isArray(boot?.added)?boot.added:null;
  if(!boot){
    const [overlayRows, addedRows]=await Promise.all([fetchOverlayRows(sb), fetchAddedRows(sb)]);
    overlay=overlayRows;
    added=addedRows;
  }
  const base=await basePromise.catch(()=>[]);
  if(!base?.length){
    // No public static base: read every lead straight from Supabase.
    let count=remoteCount;
    if(count==null){
      const head=await sb.from('leads').select('id',{count:'exact',head:true});
      if(head.error) throw head.error;
      count=head.count;
    }
    const rows=(await fetchAllParallel(()=>sb.from('leads').select('*').order('id'), count)).map(normalizeLead);
    const stamp=remoteUpdatedAt||normalizeStamp(newestUpdatedAt(rows));
    if(current()) rememberLeadCache(stamp, rows);
    return rows;
  }
  const fixes=await fetchCoordFixes(sb, base).catch(()=>[]);
  let merged=mergeLeadOverlay(base, [...(overlay||[]), ...(fixes||[])], added||[]).map(normalizeLead);
  if(remoteCount!=null && merged.length!==Number(remoteCount)){
    merged=(await fetchAllParallel(()=>sb.from('leads').select('*').order('id'), remoteCount)).map(normalizeLead);
  }
  const stamp=remoteUpdatedAt||normalizeStamp(newestUpdatedAt(merged));
  if(current()) rememberLeadCache(stamp, merged);
  return merged;
}
async function fetchOverlayRows(sb){
  const head=await sb.from('leads').select('id',{count:'exact',head:true}).or(LEAD_OVERLAY_OR);
  if(head.error) throw head.error;
  return fetchAllParallel(()=>sb.from('leads').select(LEAD_OVERLAY_COLUMNS).or(LEAD_OVERLAY_OR).order('id'), head.count||0);
}
async function fetchAddedRows(sb){
  const filter=`source.is.null,source.not.in.("${STATIC_LEAD_SOURCES.join('","')}")`;
  const {data, error}=await sb.from('leads').select('*').or(filter);
  if(error) throw error;
  return data||[];
}
async function fetchCoordFixes(sb, leads){
  const ids=(leads||[]).filter(lead=>lead?.lat==null||lead?.lng==null).map(lead=>lead.id).filter(Boolean);
  const out=[];
  for(let index=0; index<ids.length; index+=80){
    const {data, error}=await sb.from('leads').select('id,lat,lng,geocode_match').in('id', ids.slice(index, index+80));
    if(error) return out;
    for(const row of data||[]) if(row?.lat!=null && row?.lng!=null) out.push(row);
  }
  return out;
}
function replaceLeads(rows){
  state.stopLeadRead?.();
  state.paintTicket++;
  const normalized=rows.map(normalizeLead);
  state.leads=normalized;
  state.leadsById=new Map(normalized.map(lead=>[lead.id, lead]));
  state.clusterSource=null;
  state.clusterSig='';
  state.clusterZoom=null;
  state.listFilterKey='';
  state.listRows=null;
  state.heatKey='';
  state.territoryKey='';
  if($('datasetCount')) $('datasetCount').textContent=`${fmt(normalized.length)} live leads`;
  if(!state.map) initMapOnce();
  const fit=!state.didFit;
  state.bootDone=true;
  state.leadLoadSettled=true;
  buildFilters();
  renderNow(fit);
  markFirstPins();
  warmFieldLayers();
}
function resetLeadStream(){
  state.leads=[];
  state.leadsById=new Map();
  state.listFilterKey='';
  state.listRows=null;
  state.bootDone=false;
  state.leadLoadSettled=false;
  state.clusterSource=null;
  state.clusterZoom=null;
  state.territoryKey='';
}
function streamLeads(rows, total, meta){
  const ticket=++state.paintTicket;
  resetLeadStream();
  let index=0;
  const size=2000;
  const step=()=>{
    if(ticket!==state.paintTicket) return;
    const end=Math.min(rows.length, index+size);
    const chunk=[];
    for(let i=index;i<end;i++) chunk.push(rows[i]);
    index=end;
    ingestLeadChunk(chunk, meta, total||rows.length, index>=rows.length);
    if(index<rows.length) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}
function ingestLeadChunk(rows, meta, total, isLast){
  const saved=meta||{};
  rows.forEach(raw=>{
    const extra=saved[raw.id]||{};
    const lead=normalizeLead({...raw, ...extra, assignedRepName:extra.owner||raw.assignedRepName||''});
    state.leads.push(lead);
    state.leadsById.set(lead.id, lead);
  });
  const totalCount=total||state.leads.length;
  setBootProgress(state.leads.length, totalCount);
  if(isLast) state.leadLoadSettled=true;
  const first=!state.bootDone;
  if(first){
    buildFilters();
    renderNow(isLast);
    state.bootDone=true;
    state.pinsPainted=true;
    markFirstPins();
    settleMapLoader(state.mapLoaderGen);
  }else if(!isLast){
    applyFilters();
    syncPins();
    renderSidebarCounts();
  }
  if(isLast){
    if(!first){
      state.listFilterKey='';
      buildFilters();
      renderNow(true);
    }
    warmFieldLayers();
  }
}
function setBootProgress(done, total){
  const text=total?`Loading ${fmt(done)} of ${fmt(total)} homes…`:'Loading homes…';
  const label=$('bootText'); if(label) label.textContent=text;
  const bar=$('bootBar'); if(bar) bar.style.width=`${total?Math.min(100, Math.round(done/Math.max(1,total)*100)):8}%`;
}
function hideBoot(){hideMapLoader(state.mapLoaderGen);}
function warmFieldLayers(){
  if(state.fieldWarmed)return;
  state.fieldWarmed=true;
  if(state.layerFlags.radar||state.layerFlags.warnings||state.layerFlags.reports) ensureStormMaps();
  weatherApi().then(mod=>mod.startMapWeather(state.map)).catch(()=>{});
}
async function fetchAll(makeBuilder){
  const out=[]; let from=0,step=1000;
  while(true){const {data,error}=await makeBuilder().range(from,from+step-1);if(error)throw error;if(!data?.length)break;out.push(...data);if(data.length<step)break;from+=step;}
  return out;
}
async function fetchAllParallel(makeBuilder, count){
  const total=Number(count);
  if(!Number.isFinite(total) || total<=0) return [];
  const ranges=pageRanges(total, 1000);
  const pages=await Promise.all(ranges.map(([from, to])=>makeBuilder().range(from, to)));
  const out=[];
  for(const result of pages){
    if(result.error) throw result.error;
    if(result.data?.length) out.push(...result.data);
  }
  return out;
}

function normalizeLead(l){return {...l,status:l.status||'New',assignedRepId:l.assigned_rep_id||l.assignedRepId||null,roofAgeYears:l.roof_age_years??l.roofAgeYears??null,roofAgeVerified:l.roof_age_verified??l.roofAgeVerified??false,lat:l.lat??null,lng:l.lng??null};}

function scrubPrivateMap(){
  state.paintTicket++;
  state.stopLeadRead?.();
  state.leads=[];
  state.filtered=[];
  state.leadsById=new Map();
  state.appointments=[];
  state.activities=[];
  state.reps=[];
  state.territories=[];
  state.selected.clear();
  state.routeStops=[];
  state.bootDone=false;
  state.pinsPainted=false;
  state.cloudReady=false;
  state.didFit=false;
  state.session=null;
  state.user=null;
  state.currentRep=null;
  cloudToken='';
  if(state.navWatch!=null){ navigator.geolocation.clearWatch(state.navWatch); state.navWatch=null; }
  state.navigating=false;
  document.documentElement.classList.remove('isNavigating');
  try{ state.pinMarkers.forEach(marker=>marker.remove()); }catch{ /* map already gone */ }
  state.pinMarkers.clear();
  state.pinShown.clear();
  state.markerLayer?.clearLayers?.();
  state.pinClusters?.clearLayers?.();
  state.heatLayers.forEach(layer=>state.map?.removeLayer(layer));
  state.heatLayers=[];
  if(state.map){ state.map.remove(); state.map=null; }
  state.tileLayer=null;
  state.routeLine=null;
  state.userMarker=null;
  ['workList','handoffList','teamList','routeStops','stats','drawerContent','doorSheetActions'].forEach(id=>{ const el=$(id); if(el) el.innerHTML=''; });
  ['doorSheetAddress','doorSheetName','doorSheetPlace','doorSheetStatus','toastText','userIdentity','datasetCount','mapInfoCount','mapInfoNext','search'].forEach(id=>{
    const el=$(id);
    if(!el) return;
    if(el.tagName==='INPUT' || el.tagName==='TEXTAREA') el.value='';
    else el.textContent='';
  });
  ['drawer','doorSheet','navBar','routePanel','appointmentModal','adminModal','postSignIn','navChoice'].forEach(id=>$(id)?.classList.add('hidden'));
  const book=$('doorSheetBook'); if(book) book.setAttribute('href','/setter.html');
  document.getElementById('tnFieldOps')?.remove();
  document.getElementById('tnMsgOverlay')?.remove();
  $('userMenu')?.classList.add('hidden');
  $('appShell')?.classList.remove('blurred');
}
function showLogin(){
  if(state.cacheScope) clearLeadCache();
  state.cacheScope='';
  authEpoch++;
  cloudFlight=null;
  state.sessionReady=false;
  document.documentElement.classList.add('tn-signed-out');
  const logo=document.querySelector('#loginModal .signInLogo');
  if(logo && !logo.getAttribute('src')) logo.src=logo.dataset.src||'/brand/logo-full.webp';
  $('loginModal')?.classList.remove('hidden');
  if($('loginError')) $('loginError').textContent='';
  const note=$('loginNote');
  if(note) note.textContent=new URLSearchParams(location.search).get('reset')==='1'?PASSWORD_UPDATED:'';
  scrubPrivateMap();
  import('./tn-files/password-reset.js').catch(()=>{});
}
function hideLogin(){
  document.documentElement.classList.remove('tn-signed-out');
  $('loginModal')?.classList.add('hidden');
  $('appShell')?.classList.remove('blurred');
  if($('loginError')) $('loginError').textContent='';
  revealMapLoader();
}
async function login(e){e.preventDefault();if(!state.supabase){return}
  state.pendingPostSignIn=true;
  $('loginError').textContent='Signing in…';
  const {error}=await state.supabase.auth.signInWithPassword({email:$('loginEmail').value.trim(),password:$('loginPassword').value});
  if(error){state.pendingPostSignIn=false;$('loginError').textContent=error.message}
}
function showPostSignIn(){
  const panel=$('postSignIn'); if(!panel) return;
  const who=state.currentRep?.name||state.user?.email||'';
  $('postSignInWho').textContent=who?`${who} is signed in. Management is part of this profile.`:'You are signed in. Management is part of this profile.';
  $('postSignInLinks').innerHTML=MANAGEMENT_LINKS.map(link=>`<a class="postSignInLink" href="${esc(link.href)}"><b>${esc(link.label)}</b><span>${esc(link.hint||'')}</span></a>`).join('');
  panel.classList.remove('hidden');
}
function showFatal(e){$('workList').innerHTML=`<div class="empty"><b>Could not load command center.</b><br>${esc(e.message)}</div>`}

function initMapOnce(){
  if(state.map)return;
  state.map=L.map('map',{zoomControl:true,preferCanvas:true}).setView([40.39,-82.49],11);
  installMapBearing(state.map);
  const gen=beginMapLoader(false);
  state.tileLayer=L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:20,attribution:'© OpenStreetMap contributors',updateWhenIdle:true,keepBuffer:2}).addTo(state.map);
  state.tileLayer.on('load',()=>settleMapLoader(state.mapLoaderGen));
  state.pinRenderer=L.canvas({padding:.5});
  state.markerLayer=L.layerGroup().addTo(state.map);
  state.pinClusters=L.layerGroup().addTo(state.map);
  state.map.on('dragstart',()=>{ if(state.navigating&&state.navFollow){state.navFollow=false;state.navPanUntil=0;state.map.stop();syncRecenterButton();} });
  state.map.on('zoomstart',()=>{ if(state.navigating&&state.navFollow&&!state.navAutoMove){state.navFollow=false;syncRecenterButton();} });
  state.map.on('moveend',()=>{ if(state.layerFlags.pins) onNavMapMove(); });
  if(!state.map.getPane('radarPane')){
    const pane=state.map.createPane('radarPane');
    pane.style.zIndex='350';
    pane.style.pointerEvents='none';
  }
  requestAnimationFrame(()=>state.map?.invalidateSize());
  return gen;
}
function reducedMotion(){return window.matchMedia('(prefers-reduced-motion: reduce)').matches}
function rotateMapFacts(){
  const el=$('mapLoaderFact'); if(!el||state.factTimer)return;
  let index=0;
  const apply=()=>{el.textContent=MAP_FACTS[index%MAP_FACTS.length];};
  apply();
  state.factTimer=setInterval(()=>{
    const next=()=>{index+=1;apply();el.classList.remove('isFading');};
    if(reducedMotion()){next();return;}
    el.classList.add('isFading');
    setTimeout(next, 320);
  }, 4000);
}
function revealMapLoader(){
  const el=$('mapLoader'); if(!el)return;
  el.classList.toggle('isRefresh',state.bootDone);
  el.classList.remove('isDone','isGone');
  delete el.dataset.hiding;
  el.setAttribute('aria-busy','true');
  if(state.bootDone){
    const label=$('bootText');
    if(label) label.textContent='Updating the map…';
  }
}
function hideMapLoader(gen){
  if(!state.sessionReady) return;
  if(gen!=null&&gen!==state.mapLoaderGen)return;
  clearTimeout(state.mapLoaderGiveUp);
  const el=$('mapLoader'); if(!el||el.classList.contains('isGone')||el.dataset.hiding==='1'){state.mapSettled=true;return;}
  el.dataset.hiding='1';
  el.classList.add('isDone');
  el.setAttribute('aria-busy','false');
  state.mapSettled=true;
  const finish=()=>{if(el.classList.contains('isDone'))el.classList.add('isGone');};
  if(reducedMotion())finish();
  else{el.addEventListener('transitionend',finish,{once:true});setTimeout(finish,480);}
}
function mapTilesPending(){
  const imgs=document.querySelectorAll('#map .leaflet-tile-pane img.leaflet-tile');
  if(!imgs.length)return true;
  return [...imgs].some(img=>!img.complete);
}
function beginMapLoader(showNow){
  const gen=++state.mapLoaderGen;
  state.pinsPainted=false;
  clearTimeout(state.mapLoaderGiveUp);
  state.mapLoaderGiveUp=null;
  if(showNow)revealMapLoader();
  return gen;
}
function settleMapLoader(gen){
  if(gen!==state.mapLoaderGen||!state.pinsPainted||state.awaitingFirstFit)return;
  if(!state.mapLoaderGiveUp)state.mapLoaderGiveUp=setTimeout(()=>hideMapLoader(gen),12000);
  state.map?.invalidateSize();
  requestAnimationFrame(()=>requestAnimationFrame(()=>{
    if(gen!==state.mapLoaderGen||!state.pinsPainted||state.awaitingFirstFit)return;
    if(mapTilesPending())return;
    hideMapLoader(gen);
  }));
}

function syncFilters(){
  state.filters={q:$('search').value.trim().toLowerCase(),status:$('statusFilter').value,rep:$('repFilter').value,territory:$('territoryFilter').value,source:$('sourceFilter').value,mine:$('mineToggle').checked};
}
function buildFilters(){
  const territory=$('territoryFilter').value, rep=$('repFilter').value, source=$('sourceFilter').value;
  const cities=[...new Set(state.leads.map(l=>l.city).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
  const territories=cities.map(city=>({name:city,city}));
  const reps=state.reps.slice().sort((a,b)=>a.name.localeCompare(b.name));
  fillSelect('repFilter','All reps',reps.map(r=>({value:r.id,label:r.name})));
  fillSelect('territoryFilter','All territories',territories.map(t=>({value:t.city,label:t.city})));
  fillSelect('sourceFilter','All sources',[...new Set(state.leads.map(l=>l.source).filter(Boolean))].sort().map(x=>({value:x,label:x})));
  if(territory)$('territoryFilter').value=territory;
  if(rep)$('repFilter').value=rep;
  if(source)$('sourceFilter').value=source;
}
function fillSelect(id,first,items){$(id).innerHTML=`<option value="">${esc(first)}</option>`+items.map(x=>`<option value="${esc(x.value)}">${esc(x.label)}</option>`).join('');}

function applyFilters(){
  const f=state.filters;
  const storm=state.stormHouseIds;
  state.filtered=state.leads.filter(l=>{
    if(storm&&!storm.has(l.id))return false;
    const blob=[l.name,l.address,l.city,l.state,l.zip,l.record_id,l.recordId,l.id,l.full_address,l.fullAddress].join(' ').toLowerCase();
    return (!f.q||blob.includes(f.q)) && (!f.status||leadStatus(l)===f.status) && (!f.rep||l.assignedRepId===f.rep) && (!f.territory||l.city===f.territory) && (!f.source||l.source===f.source) && (!f.mine||!state.currentRep||l.assignedRepId===state.currentRep.id||(state.territories.find(t=>t.name===l.city)?.assigned_rep_id===state.currentRep.id));
  });
}

function renderAll(){
  if(!state.map)return;
  applyFilters();
  state.listFilterKey='';
  if(state.renderQueued)return;
  state.renderQueued=true;
  requestAnimationFrame(()=>{state.renderQueued=false;renderNow()});
}
function renderNow(fit=true){
  if(!state.map)return;
  applyFilters();
  renderSidebarCounts();
  refreshMapLayers();
  updateSelectedBadge();
  updatePinBanner();
  state.pinsPainted=true;
  if(fit && !state.didFit){
    state.didFit=true;
    state.awaitingFirstFit=true;
    setTimeout(()=>{publishListPeek();fitMapToScope(false);state.awaitingFirstFit=false;if(state.layerFlags.pins) syncPins();settleMapLoader(state.mapLoaderGen);},80);
  }
  settleMapLoader(state.mapLoaderGen);
  const token=++state.listSortToken;
  requestAnimationFrame(()=>{
    if(token!==state.listSortToken)return;
    renderStats();
    renderWorkList();
    renderHandoffs();
    renderTeam();
    updateListSummary();
    updateFilterBadge();
  });
}

function renderStats(){
  const total=state.filtered.length;
  const knocked=state.filtered.filter(l=>['Knocked','No Answer','Interested','Not Interested','Do Not Knock'].includes(leadStatus(l))).length;
  const appts=state.appointments.filter(a=>a.stage!=='Cancelled').length;
  const pinned=state.filtered.filter(isCoords).length;
  $('stats').innerHTML=`<div class="stat"><b>${fmt(total)}</b><span>filtered leads</span></div><div class="stat"><b>${fmt(pinned)}</b><span>mapped houses</span></div><div class="stat"><b>${fmt(knocked)}</b><span>worked</span></div><div class="stat"><b>${fmt(appts)}</b><span>appointments</span></div>`;
  const start=new Date(); start.setHours(0,0,0,0);
  const todayActivities=state.activities.filter(a=>new Date(a.created_at).getTime()>=start.getTime());
  const workedToday=todayActivities.filter(a=>['Knocked','No Answer','Interested','Not Interested','Do Not Knock'].includes(a.metadata?.to_status)).length;
  const apptsToday=state.appointments.filter(a=>a.stage!=='Cancelled'&&new Date(a.scheduled_at).getTime()>=start.getTime()&&new Date(a.scheduled_at).getTime()<start.getTime()+86400000).length;
  const highPriority=state.filtered.filter(l=>l.priority==='High'&&scoreLead(l)>-1000).length;
  $('todayWorked').textContent=fmt(workedToday); $('todayAppts').textContent=fmt(apptsToday); $('highPriorityCount').textContent=fmt(highPriority);
}
function renderSidebarCounts(){
  $('workCount').textContent=fmt(state.filtered.length);
  $('handoffCount').textContent=fmt(state.appointments.filter(a=>!['Completed','Cancelled'].includes(a.stage)).length);
  $('teamCount').textContent=fmt(state.reps.length);
}

function ensureListRows(){
  const key=JSON.stringify(state.filters)+':'+(state.stormHouseIds?state.stormHouseIds.size:0)+':'+state.leads.length;
  if(state.listFilterKey===key && state.listRows) return;
  const previous=state.listFilterKey;
  state.listFilterKey=key;
  state.listRows=state.filtered.slice().sort((a,b)=>scoreLead(b)-scoreLead(a));
  state.listShown=180;
  state.listPaintToken='';
  if(previous) $('workList').scrollTop=0;
}
function renderWorkList(){state.listPaintToken='';paintWorkList()}
function paintWorkList(){
  const list=$('workList'); if(!list) return;
  ensureListRows();
  const rows=state.listRows||[];
  if(!rows.length){list.innerHTML='<div class="empty"><b>No houses match these filters.</b><br>Try Reset, change territory, or use the map search.</div>';return}
  if(list.clientHeight<40){paintPagedList(list, rows);return}
  const rowH=84;
  const start=Math.max(0, Math.floor(list.scrollTop/rowH)-3);
  const end=Math.min(rows.length, Math.ceil((list.scrollTop+list.clientHeight)/rowH)+6);
  const token=`${state.listFilterKey}:${start}:${end}:${state.selected.size}:${state.active||''}`;
  if(state.listPaintToken===token) return;
  state.listPaintToken=token;
  const scroll=list.scrollTop;
  list.innerHTML=`<div style="height:${start*rowH}px"></div>${rows.slice(start,end).map(leadHTML).join('')}<div style="height:${Math.max(0,(rows.length-end)*rowH)}px"></div>`;
  list.scrollTop=scroll;
  bindListRows(list);
}
function paintPagedList(list, rows){
  const shown=Math.min(rows.length, state.listShown||180);
  const top=rows.slice(0, shown);
  const more=rows.length>shown?`<button type="button" id="showMoreLeads" class="showMoreLeads">Show more · ${fmt(shown)} of ${fmt(rows.length)}</button>`:'';
  const scroll=list.scrollTop;
  list.innerHTML=top.map(leadHTML).join('')+more;
  list.scrollTop=scroll;
  bindListRows(list);
  $('showMoreLeads')?.addEventListener('click',()=>{state.listShown=Math.min(rows.length, shown+180);state.listPaintToken='';paintPagedList(list, rows)});
}
function bindListRows(list){
  list.querySelectorAll('.leadRow').forEach(el=>el.onclick=e=>{if(e.target.closest('.rowCheck'))return;openLead(el.dataset.id)});
  list.querySelectorAll('.rowCheck').forEach(cb=>cb.onchange=()=>{cb.checked?state.selected.add(cb.dataset.id):state.selected.delete(cb.dataset.id);updateSelectedBadge();refreshSelectedMarkers();syncRouteButtons(cb.dataset.id)});
}
function leadHTML(l){
  const s=leadStatus(l), owner=leadOwnerName(l), score=scoreLead(l), old=l.year_built??l.yearBuilt;
  const appointment=state.appointments.find(a=>a.lead_id===l.id&&a.stage!=='Cancelled');
  const territoryRep=state.reps.find(r=>r.id===state.territories.find(t=>t.name===l.city)?.assigned_rep_id)?.name||'';
  const distance=state.currentLocation&&isCoords(l)?haversine(state.currentLocation.lat,state.currentLocation.lng,l.lat,l.lng):null;
  return `<div class="leadRow ${state.active===l.id?'active':''}" data-id="${esc(l.id)}">
    <input class="rowCheck" type="checkbox" data-id="${esc(l.id)}" ${state.selected.has(l.id)?'checked':''}>
    <div class="rowBody"><div class="rowHeader"><strong>${esc(l.name||'Property lead')}</strong><span class="status ${statusClass(s)}">${esc(s)}</span></div>
    <div class="addr">${esc(l.address)}<br><span>${esc(l.city)}, ${esc(l.state)} ${esc(l.zip)}</span></div>
    <div class="rowMeta"><span class="score">${score} pts</span>${l.priority==='High'?`<span class="priorityTag">HIGH</span>`:''}${distance!=null?`<span>${distance.toFixed(1)} mi</span>`:''}${old?`<span>Built ${esc(old)}</span>`:''}${owner?`<span>${esc(owner)}</span>`:''}${territoryRep?`<span>Territory · ${esc(territoryRep)}</span>`:''}${appointment?`<span class="apptTag">APPT</span>`:''}</div></div></div>`;
}
function statusClass(s){return s.toLowerCase().replace(/\s+/g,'-')}

const HANDOFF_PREVIEW_KEY='tnrc2:handoffPreview';
function handoffActor(){
  if(state.mode==='cloud' && state.currentRep) return {role:state.currentRep.role||'', repId:state.currentRep.id||''};
  if(state.mode==='local'){
    try{
      const preview=JSON.parse(sessionStorage.getItem(HANDOFF_PREVIEW_KEY)||'null');
      if(preview && typeof preview.role==='string') return {role:preview.role, repId:preview.repId||''};
    }catch{}
    return {role:'admin', repId:'local'};
  }
  return {role:'', repId:''};
}
function renderHandoffs(){
  const list=$('handoffList');
  const actor=handoffActor();
  const appts=visibleHandoffs({role:actor.role, repId:actor.repId, appointments:state.appointments}).slice(0,120);
  list.innerHTML=appts.length?appts.map(a=>appointmentHTML(a)).join(''):'<div class="empty">No open appointments.</div>';
  list.querySelectorAll('[data-appt]').forEach(el=>el.onclick=()=>openAppointment(el.dataset.appt));
  const bar=$('repReceiptBar');
  if(bar) bar.classList.toggle('hidden', actor.role!=='salesperson');
}
function appointmentHTML(a){
  const l=state.leads.find(x=>x.id===a.lead_id)||{};
  return `<div class="appointmentRow" data-appt="${esc(a.id)}"><div><strong>${esc(l.name||'Appointment')}</strong><div>${esc(l.address||'')}</div><small>${esc(formatDate(a.scheduled_at))} · ${esc(a.stage)}</small></div><span class="chev">›</span></div>`;
}
function formatDate(v){try{return new Intl.DateTimeFormat(undefined,{dateStyle:'medium',timeStyle:'short'}).format(new Date(v))}catch{return String(v||'')}}

function renderTeam(){
  const list=$('teamList');
  const cutoff=Date.now()-7*86400000;
  const by={}; state.reps.forEach(r=>by[r.id]={rep:r,knocks:0,appts:0,interested:0});
  state.activities.filter(a=>new Date(a.created_at).getTime()>=cutoff).forEach(a=>{if(!by[a.actor_id])return; const to=a.metadata?.to_status; if(['Knocked','No Answer','Interested','Not Interested','Do Not Knock'].includes(to))by[a.actor_id].knocks++;if(to==='Interested')by[a.actor_id].interested++;if(a.action==='appointment_booked')by[a.actor_id].appts++});
  const rows=Object.values(by).sort((a,b)=>(b.appts*10+b.interested*2+b.knocks)-(a.appts*10+a.interested*2+a.knocks));
  list.innerHTML=rows.map((x,i)=>`<div class="teamRow"><div class="rank">${i+1}</div><div class="teamName"><strong>${esc(x.rep.name)}</strong><small>${esc(roleLabel(x.rep.role))}</small></div><div><b>${x.knocks}</b><small>worked</small></div><div><b>${x.appts}</b><small>appts</small></div></div>`).join('')||'<div class="empty">No team members configured.</div>';
}

function scoreLead(l){
  const s=leadStatus(l);
  if(l._score!=null && l._scoreKey===s) return l._score;
  let score=0;
  if(s==='Do Not Knock'||s==='Appointment'||s==='Not Interested')return -1000;
  if(s==='Interested')score+=55; else if(s==='No Answer')score+=24; else if(s==='Knocked')score+=12; else score+=32;
  if(l.priority==='High')score+=45;
  if(String(l.owner_occupied||l.ownerOccupied)==='Y')score+=18;
  const year=Number(l.year_built??l.yearBuilt);
  if(year){const age=Math.max(0,2026-year);score+=Math.min(35,Math.round(age*.8));}
  const roofAge=Number(l.roof_age_years??l.roofAgeYears);
  if(roofAge)score+=Math.min(28,Math.round(roofAge*1.3));
  if(l.city&&state.territories.find(t=>t.name===l.city)?.assigned_rep_id===state.currentRep?.id)score+=8;
  if(isCoords(l)&&state.currentLocation){score+=Math.max(0,20-Math.round(haversine(state.currentLocation.lat,state.currentLocation.lng,l.lat,l.lng)*3));}
  l._scoreKey=s;
  l._score=Math.round(score);
  return l._score;
}

function refreshMapLayers(){
  if(!state.map)return;
  const slow=state.mapSettled && mapTilesPending();
  if(slow){
    const gen=beginMapLoader(true);
    requestAnimationFrame(()=>{
      if(gen!==state.mapLoaderGen)return;
      syncPins();
      syncDecorations();
      state.pinsPainted=true;
      settleMapLoader(gen);
    });
    return;
  }
  syncPins();
  syncDecorations();
}
function syncDecorations(){
  const territoryKey=state.layerFlags.territories?`${state.filtered.length}:${JSON.stringify(state.filters)}:${state.stormHouseIds?state.stormHouseIds.size:0}`:'off';
  if(territoryKey!==state.territoryKey){
    (state._territoryLayers||[]).forEach(x=>x.remove());
    state._territoryLayers=[];
    state.territoryKey=territoryKey;
    if(state.layerFlags.territories)drawTerritories();
  }
  if(state.routeLine){state.map.removeLayer(state.routeLine);state.routeLine=null}
  if(state.routeStops?.length)drawRoutePreview(false);
  else if(state.navigating)drawNavOverlay();
  scheduleHeat();
}
function scheduleHeat(){
  clearTimeout(state.heatTimer);
  const want=state.layerFlags.density||state.layerFlags.opportunity||state.layerFlags.roofAge;
  if(!want){state.heatLayers.forEach(layer=>layer.remove());state.heatLayers=[];state.heatKey='';return}
  state.heatTimer=setTimeout(()=>{ ensureHeat().then(()=>{ if(window.L?.heatLayer) rebuildHeat(); }).catch(()=>{}); }, 180);
}
let heatPromise;
function ensureHeat(){
  if(window.L?.heatLayer) return Promise.resolve();
  heatPromise ||= new Promise((resolve, reject)=>{
    const script=document.createElement('script');
    script.src='/vendor/leaflet/leaflet-heat.js';
    script.onload=()=>resolve();
    script.onerror=()=>reject(new Error('heat map did not load'));
    document.head.appendChild(script);
  });
  return heatPromise;
}
function rebuildHeat(){
  const key=[state.layerFlags.density,state.layerFlags.opportunity,state.layerFlags.roofAge,state.filtered.length,state.listFilterKey].join(':');
  if(key===state.heatKey)return;
  state.heatLayers.forEach(layer=>layer.remove());
  state.heatLayers=[];
  state.heatKey=key;
  if(state.layerFlags.density)drawHeat('density');
  if(state.layerFlags.opportunity)drawHeat('opportunity');
  if(state.layerFlags.roofAge)drawHeat('roof');
}
const PIN_COLORS={new:'#1e6bff',knocked:'#3E4E59','no-answer':'#A66B19',interested:'#467c9e','not-interested':'#8c5e54','do-not-knock':'#A44835',appointment:'#2E6B4B'};
function stylePin(marker, lead){
  const selected=state.selected.has(lead.id);
  const color=selected?'#c54f32':(PIN_COLORS[statusClass(leadStatus(lead))]||'#1e6bff');
  marker.setStyle({radius:selected?9:7, fillColor:color, color:selected?'#fff':'#0c1424', weight:selected?2:1, fillOpacity:.95});
}
function pinPopupHtml(lead){
  const s=leadStatus(lead);
  return `<div class="pinPopup"><b>${esc(lead.name||'Property lead')}</b><div>${esc(lead.address)}, ${esc(lead.city)}</div><div class="popupLine"><span class="miniBadge">${esc(s)}</span><b>${scoreLead(lead)} pts</b></div><div class="popupActions"><button type="button" class="routeToggle" data-popup-route="${esc(lead.id)}">${routeToggleLabel(state.selected.has(lead.id))}</button><button type="button" data-popup-lead="${esc(lead.id)}">Open lead</button></div></div>`;
}
function bindPinPopup(lead){
  setTimeout(()=>{
    const routeBtn=document.querySelector(`[data-popup-route="${CSS.escape(lead.id)}"]`);
    routeBtn?.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();toggleSelected(lead.id);if(routeBtn)routeBtn.textContent=routeToggleLabel(state.selected.has(lead.id));stylePin(state.pinMarkers.get(lead.id), lead)});
    document.querySelector(`[data-popup-lead="${CSS.escape(lead.id)}"]`)?.addEventListener('click',()=>openLead(lead.id));
  },0);
}
function ensurePin(lead){
  let marker=state.pinMarkers.get(lead.id);
  if(marker) return marker;
  marker=L.circleMarker([Number(lead.lat), Number(lead.lng)],{renderer:state.pinRenderer, radius:7, weight:1, color:'#0c1424', fillColor:'#1e6bff', fillOpacity:.95});
  marker._leadId=lead.id;
  stylePin(marker, lead);
  if(useDoorSheet()) marker.on('click', event=>{L.DomEvent.stop(event);openDoorSheet(lead.id)});
  else {marker.bindPopup(()=>pinPopupHtml(state.leadsById.get(lead.id)||lead)); marker.on('popupopen',()=>bindPinPopup(state.leadsById.get(lead.id)||lead))}
  state.pinMarkers.set(lead.id, marker);
  return marker;
}
function clusterIcon(count){
  const size=count>999?46:count>99?40:34;
  return L.divIcon({className:'pinCluster', html:`<span>${fmt(count)}</span>`, iconSize:[size,size], iconAnchor:[size/2,size/2]});
}
function hideStreetPins(){
  state.pinShown.forEach(id=>state.pinMarkers.get(id)?.remove());
  state.pinShown.clear();
}
function onNavMapMove(){
  if(state.navigating&&state.navFollow){
    if(state.navPinTimer) return;
    state.navPinTimer=setTimeout(()=>{
      state.navPinTimer=0;
      if(!state.navigating||!state.navFollow||!state.map) return;
      const bounds=state.map.getBounds();
      const key=`${Math.round(state.map.getZoom())}:${bounds.getSouth().toFixed(3)}:${bounds.getWest().toFixed(3)}`;
      if(key===state.navPinKey) return;
      state.navPinKey=key;
      syncPins({restyle:false});
    }, 900);
    return;
  }
  syncPins();
}
function syncPins(options={}){
  if(!state.map)return;
  if(!state.layerFlags.pins){hideStreetPins();state.pinClusters?.clearLayers();state.clusterSig='';state.clusterSource=null;return}
  const zoom=state.map.getZoom();
  if(zoom<STREET_ZOOM){
    hideStreetPins();
    if(state.clusterSource===state.filtered && state.clusterZoom===zoom && state.clusterSig) return;
    const clusters=clusterLeads(state.filtered, zoom);
    state.clusterSig=`${zoom}:${clusters.length}:${state.filtered.length}`;
    state.clusterSource=state.filtered;
    state.clusterZoom=zoom;
    state.pinClusters.clearLayers();
    clusters.forEach(cluster=>{
      const marker=L.marker([cluster.lat, cluster.lng],{icon:clusterIcon(cluster.count), keyboard:true, title:`${fmt(cluster.count)} homes`});
      marker.on('click',()=>state.map.setView([cluster.lat, cluster.lng], Math.min(STREET_ZOOM, zoom+2)));
      state.pinClusters.addLayer(marker);
    });
    return;
  }
  if(state.clusterSig){state.pinClusters.clearLayers();state.clusterSig='';state.clusterSource=null;state.clusterZoom=null}
  const bounds=state.map.getBounds().pad(.2);
  const want=new Set();
  state.filtered.forEach(lead=>{if(isCoords(lead)&&bounds.contains([Number(lead.lat), Number(lead.lng)])) want.add(lead.id)});
  const diff=pinDiff(state.pinShown, want);
  diff.remove.forEach(id=>{state.pinMarkers.get(id)?.remove();state.pinShown.delete(id)});
  diff.add.forEach(id=>{
    const lead=state.leadsById.get(id);
    if(!lead)return;
    ensurePin(lead).addTo(state.markerLayer);
    state.pinShown.add(id);
  });
  if(options.restyle!==false) want.forEach(id=>{const lead=state.leadsById.get(id), marker=state.pinMarkers.get(id); if(lead&&marker) stylePin(marker, lead)});
}
function useDoorSheet(){return doorSheetMedia.matches;}
function drawHeat(kind){
  const points=sampleHeat(state.filtered).map(l=>{let intensity=.2;if(kind==='density')intensity=.35;else if(kind==='opportunity')intensity=Math.min(1,Math.max(.05,scoreLead(l)/140));else{const y=Number(l.year_built??l.yearBuilt), roof=Number(l.roof_age_years??l.roofAgeYears);const age=roof|| (y?2026-y:0);intensity=Math.min(1,Math.max(.08,age/45));}return [Number(l.lat),Number(l.lng),intensity]});
  if(!points.length)return;
  const layer=L.heatLayer(points,{radius:24,blur:18,maxZoom:17,minOpacity:.20}).addTo(state.map); state.heatLayers.push(layer);
}
function drawTerritories(){
  const cities=groupByCity(state.filtered);
  Object.entries(cities).forEach(([city,leads])=>{
    const coords=leads.filter(isCoords); let center=state.centers?.[city];
    if(coords.length){center=[avg(coords.map(x=>Number(x.lat))),avg(coords.map(x=>Number(x.lng)))];}
    if(!center)return;
    const t=state.territories.find(x=>x.name===city)||{};
    const rep=state.reps.find(r=>r.id===t.assigned_rep_id)?.name||'Unassigned';
    const circle=L.circle(center,{radius:Math.max(400,Math.min(4200,Math.sqrt(leads.length)*95)),weight:1.5,fillOpacity:.06,color:t.color||'#0c1424'}).addTo(state.map);
    circle.bindPopup(`<b>${esc(city)}</b><br>${fmt(leads.length)} filtered houses<br><span>${esc(rep)}</span>`);
    state._territoryLayers.push(circle);
  });
}
function groupByCity(arr){return arr.reduce((m,l)=>{if(l.city)(m[l.city]??=[]).push(l);return m},{})}
function avg(a){return a.reduce((x,y)=>x+y,0)/Math.max(1,a.length)}

function nextBest(){
  const pool=state.filtered.filter(l=>scoreLead(l)>-100&&isCoords(l)).sort((a,b)=>scoreLead(b)-scoreLead(a));
  if(!pool.length){toast('No mapped, actionable houses are available in this filter.');return}
  openLead(pool[0].id);
  state.map.setView([pool[0].lat,pool[0].lng],17,{animate:true});
  toast(`Next best house: ${pool[0].address}`);
}

function isHomeLead(l){return isCoords(l)&&haversine(HOME_BASE.lat,HOME_BASE.lng,Number(l.lat),Number(l.lng))<=HOME_MILES;}
function fitMapToScope(animate=false){
  if(!state.map||state.navigating)return;
  const mapped=state.filtered.filter(isCoords);
  const home=mapped.filter(isHomeLead);
  const use=state.homeArea&&home.length?home:mapped;
  if(!use.length){state.map.setView([HOME_BASE.lat,HOME_BASE.lng],12,{animate});watchSlowTiles();return;}
  const bounds=L.latLngBounds(use.map(l=>[Number(l.lat),Number(l.lng)]));
  const phone=useDoorSheet();
  state.map.fitBounds(bounds.pad(.12),{animate,maxZoom:16,paddingTopLeft:[16,phone?128:36],paddingBottomRight:[16,phone?150:28]});
  watchSlowTiles();
}
let tileWatch=0;
function watchSlowTiles(){
  if(!state.mapSettled)return;
  clearTimeout(tileWatch);
  tileWatch=setTimeout(()=>{
    if(!mapTilesPending())return;
    const gen=beginMapLoader(true);
    state.pinsPainted=true;
    settleMapLoader(gen);
  },320);
}
function fitFilteredLeads(){
  if(!state.filtered.filter(isCoords).length){toast('No mapped houses in the current filter.');fitMapToScope(true);return;}
  fitMapToScope(true);
}
function setHomeArea(on){
  state.homeArea=!!on;
  $('homeAreaBtn').classList.toggle('isOn',state.homeArea);
  $('homeAreaBtn').setAttribute('aria-pressed',state.homeArea?'true':'false');
  $('allOhioBtn').classList.toggle('isOn',!state.homeArea);
  $('allOhioBtn').setAttribute('aria-pressed',!state.homeArea?'true':'false');
  fitMapToScope(true);
  updateListSummary();
  updateFilterBadge();
}
function canManagePins(){return ['admin','manager'].includes(state.currentRep?.role);}
function updatePinBanner(){
  const el=$('pinBanner'); if(!el)return;
  const mapped=state.leads.some(isCoords);
  const waitingForCloud=state.mode==='cloud'&&!state.cloudReady;
  if(state.pinBannerDismissed||waitingForCloud||!state.leadLoadSettled||!state.leads.length||mapped){el.classList.add('hidden');return;}
  const admin=canManagePins();
  $('pinBannerText').textContent=admin?"Houses aren't pinned yet. Open Admin → Geocode missing house pins.":"Houses aren't pinned yet. Ask an admin to run the pin geocoder.";
  $('pinBannerAction').classList.toggle('hidden',!admin);
  el.classList.remove('hidden');
  if(useDoorSheet()){
    const canvas=document.querySelector('.mapCanvas')?.getBoundingClientRect();
    const overlay=document.querySelector('.mapTopOverlay')?.getBoundingClientRect();
    if(canvas&&overlay)el.style.top=`${Math.round(overlay.bottom-canvas.top+8)}px`;
  }else el.style.top='';
}
function compactCount(n){
  const value=Number(n)||0;
  if(value<1000)return String(value);
  if(value<10000)return `${(value/1000).toFixed(1).replace(/\.0$/,'')}k`;
  return `${Math.round(value/1000)}k`;
}
function updateListSummary(){
  const n=state.filtered.length;
  const ranked=state.listRows&&state.listRows.length===state.filtered.length?state.listRows:state.filtered;
  const next=state.homeArea?(ranked.find(l=>isHomeLead(l)&&scoreLead(l)>-100)||ranked.find(l=>!isCoords(l))||ranked[0]):ranked.find(l=>scoreLead(l)>-100)||ranked[0];
  const label=`${fmt(n)} house${n===1?'':'s'}`;
  const nextLabel=next?.address?`Next: ${next.address}`:'';
  const count=$('mapInfoCount'); if(count)count.textContent=label;
  const nextEl=$('mapInfoNext'); if(nextEl)nextEl.textContent=nextLabel;
  const badge=$('mapInfoBadge');
  if(badge){badge.hidden=false;badge.textContent=compactCount(n);}
  const toggle=$('mapInfoToggle');
  if(toggle)toggle.setAttribute('aria-label',nextLabel?`${label}. ${nextLabel}`:label);
}
function activeFilterCount(){
  let n=0;
  if(!state.homeArea)n++;
  if($('territoryFilter')?.value)n++;
  if($('repFilter')?.value)n++;
  if($('statusFilter')?.value)n++;
  if($('sourceFilter')?.value)n++;
  if($('mineToggle')?.checked)n++;
  return n;
}
function updateFilterBadge(){
  const badge=$('filterBadge');
  const btn=$('filterBtn');
  if(!badge||!btn)return;
  const n=activeFilterCount();
  badge.hidden=n===0;
  badge.textContent=String(n);
  btn.setAttribute('aria-label',n?`Filters, ${n} active`:'Filters');
}
function setFilterOpen(open){
  const panel=$('filterPanel');
  const btn=$('filterBtn');
  if(!panel||!btn)return;
  const on=!!open;
  panel.hidden=!on;
  btn.setAttribute('aria-expanded',on?'true':'false');
  if(!on)return;
  setInfoOpen(false);
  closeWeather();
  setLayersOpen(false);
  $('mapLegend')?.classList.remove('isOpen');
  $('legendKey')?.setAttribute('aria-expanded','false');
}
function setInfoOpen(open){
  const panel=$('mapInfoPanel');
  const btn=$('mapInfoToggle');
  if(!panel||!btn)return;
  const on=!!open;
  panel.hidden=!on;
  btn.setAttribute('aria-expanded',on?'true':'false');
  if(on){setFilterOpen(false);setLayersOpen(false);closeWeather();}
}
function setLayersOpen(open){
  const menu=$('layerMenu');
  if(!menu)return;
  menu.classList.toggle('open',!!open);
  $('layerBtn')?.setAttribute('aria-expanded',String(!!open));
  if(open){setFilterOpen(false);setInfoOpen(false);closeWeather();$('mapLegend')?.classList.remove('isOpen');$('legendKey')?.setAttribute('aria-expanded','false');}
}
function setListSheet(snap){
  const sheet=$('listSheet'); if(!sheet)return;
  if(!useDoorSheet()){
    sheet.classList.remove('sheet-collapsed','sheet-half','sheet-full','panel-open','sheet-suppressed');
    document.documentElement.style.setProperty('--list-sheet-peek','0px');
    return;
  }
  const next=LIST_SNAPS.includes(snap)?snap:'sheet-collapsed';
  LIST_SNAPS.forEach(name=>sheet.classList.remove(name));
  sheet.classList.add(next);
  sheet.classList.toggle('panel-open',next!=='sheet-collapsed');
  state.listSnap=next;
  $('listSheetGrab')?.setAttribute('aria-expanded',next==='sheet-collapsed'?'false':'true');
  publishListPeek();
  requestAnimationFrame(()=>renderWorkList());
}
function publishListPeek(){
  const root=document.documentElement;
  if(!useDoorSheet()){root.style.setProperty('--list-sheet-peek','0px');liftMapChrome();return;}
  const h=Math.round($('listSheetGrab')?.getBoundingClientRect().height||52);
  const bottom=getComputedStyle(root).getPropertyValue('--list-sheet-bottom').trim()||'78px';
  root.style.setProperty('--list-sheet-peek',`calc(${h}px + ${bottom})`);
  liftMapChrome();
}
function liftMapChrome(){
  const tray=$('routeTray');
  if(tray?.closest('#listSheet')){document.documentElement.style.setProperty('--route-tray-space','0px');return;}
  let height=0;
  if(tray){
    const style=getComputedStyle(tray);
    if(style.display!=='none')height=Math.round(tray.getBoundingClientRect().height);
  }
  document.documentElement.style.setProperty('--route-tray-space',`${height+8}px`);
}
function syncListMode(){setListSheet(useDoorSheet()?(state.listSnap||'sheet-collapsed'):'sheet-collapsed');syncListOverlay();}
function listOverlayOpen(){return $('doorSheet')?.classList.contains('open')||($('toast')?.classList.contains('show')&&!$('toastActions')?.classList.contains('hidden'));}
function syncListOverlay(){
  const sheet=$('listSheet'); if(!sheet)return;
  const block=listOverlayOpen()&&useDoorSheet();
  if(block&&!sheet.classList.contains('sheet-collapsed'))setListSheet('sheet-collapsed');
  sheet.classList.toggle('sheet-suppressed',block);
}
function bindListSheet(){
  const grab=$('listSheetGrab'); if(!grab)return;
  let startY=0,moved=0,dragging=false,startSnap='sheet-collapsed';
  grab.addEventListener('pointerdown',e=>{
    if(!useDoorSheet()||e.button>0)return;
    dragging=true; startY=e.clientY; moved=0; startSnap=state.listSnap||'sheet-collapsed';
    grab.setPointerCapture?.(e.pointerId);
  });
  grab.addEventListener('pointermove',e=>{if(dragging)moved=e.clientY-startY;});
  const end=()=>{
    if(!dragging)return;
    dragging=false;
    const i=Math.max(0,LIST_SNAPS.indexOf(startSnap));
    if(moved<-36&&i<LIST_SNAPS.length-1)setListSheet(LIST_SNAPS[i+1]);
    else if(moved>36&&i>0)setListSheet(LIST_SNAPS[i-1]);
    else if(Math.abs(moved)<12)setListSheet(i<LIST_SNAPS.length-1?LIST_SNAPS[i+1]:'sheet-collapsed');
  };
  grab.addEventListener('pointerup',end);
  grab.addEventListener('pointercancel',end);
  window.addEventListener('resize',()=>{syncListMode();state.map?.invalidateSize();});
}

function toggleMapFocus(){
  document.body.classList.toggle('mapFocus');
  const on=document.body.classList.contains('mapFocus');
  $('focusBtn').textContent=on?'Exit focus':'Focus map';
  setTimeout(()=>state.map.invalidateSize(),220);
}

async function quickStatus(id,status,continueNext=false){
  const l=state.leads.find(x=>x.id===id); if(!l)return;
  await persistLeadPatch(l,{status});
  if(status==='Appointment'){location.href=`/setter.html?lead=${encodeURIComponent(l.id)}`;return;}
  renderAll();
  toast(`${status} · ${l.address}`);
  if(continueNext){closeDrawer();setTimeout(nextBest,150);}
}

function openDoorSheet(id){
  const l=state.leads.find(x=>x.id===id); if(!l)return;
  dismissDoorToast();
  state.doorLeadId=id;
  state.doorSaving=false;
  state.map?.closePopup();
  const s=leadStatus(l);
  $('doorSheetAddress').textContent=l.address||'Property lead';
  const nameEl=$('doorSheetName');
  nameEl.textContent=l.name||'';
  nameEl.classList.toggle('hidden',!l.name);
  $('doorSheetPlace').textContent=[l.city,l.state,l.zip].filter(Boolean).join(', ');
  const badge=$('doorSheetStatus');
  badge.textContent=s;
  badge.className=`status ${statusClass(s)}`;
  $('doorSheetBook').href=`/setter.html?lead=${encodeURIComponent(l.id)}`;
  $('doorSheetRoute').textContent=routeToggleLabel(state.selected.has(l.id));
  $('doorSheetActions').innerHTML=DOOR_STATUSES.map(status=>`<button type="button" class="doorStatus doorStatus-${statusClass(status)}${s===status?' isCurrent':''}" data-door-status="${esc(status)}" aria-pressed="${s===status?'true':'false'}"><span class="doorStatusDot" aria-hidden="true"></span><span>${esc(status)}</span></button>`).join('');
  $('doorSheetActions').querySelectorAll('[data-door-status]').forEach(btn=>{btn.onclick=()=>applyDoorStatus(l.id,btn.dataset.doorStatus);});
  const sheet=$('doorSheet');
  const card=$('doorSheetCard');
  card.style.transform='';
  card.style.transition='';
  clearTimeout(openDoorSheet._t);
  sheet.classList.remove('hidden');
  sheet.setAttribute('aria-hidden','false');
  sheet.getBoundingClientRect();
  sheet.classList.add('open');
  syncListOverlay();
  requestAnimationFrame(()=>panPinAboveSheet(l));
}
function closeDoorSheet(){
  const sheet=$('doorSheet'); if(!sheet||sheet.classList.contains('hidden'))return;
  const card=$('doorSheetCard');
  card.style.transform='';
  card.style.transition='';
  sheet.classList.remove('open');
  sheet.setAttribute('aria-hidden','true');
  state.doorLeadId=null;
  state.doorSaving=false;
  clearTimeout(openDoorSheet._t);
  openDoorSheet._t=setTimeout(()=>{if(!sheet.classList.contains('open'))sheet.classList.add('hidden');},240);
  syncListOverlay();
}
function panPinAboveSheet(l){
  if(!state.map||!isCoords(l))return;
  const card=$('doorSheetCard');
  const mapRect=state.map.getContainer().getBoundingClientRect();
  const cardTop=window.innerHeight-(card?.offsetHeight||Math.round(window.innerHeight*0.5));
  let bandBottom=Math.min(mapRect.bottom, cardTop)-18;
  const panel=document.querySelector('.sidePanel');
  if(panel){
    const pr=panel.getBoundingClientRect();
    if(getComputedStyle(panel).display!=='none'&&pr.height>40&&pr.width>mapRect.width*0.7&&pr.top<bandBottom)bandBottom=Math.min(bandBottom, pr.top-12);
  }
  const bandTop=mapRect.top+48;
  if(bandBottom<bandTop+28)bandBottom=cardTop-18;
  const targetY=bandTop+Math.max(0, bandBottom-bandTop)*0.55;
  const pin=state.map.latLngToContainerPoint([Number(l.lat),Number(l.lng)]);
  const dy=(mapRect.top+pin.y)-targetY;
  if(Math.abs(dy)>8)state.map.panBy([0,dy],{animate:true,duration:.28});
}
function bindDoorSwipe(){
  const card=$('doorSheetCard');
  let startY=null, dragging=false;
  card.addEventListener('pointerdown',e=>{
    if(e.button>0)return;
    if(!e.target.closest('.doorSheetHead')||e.target.closest('button'))return;
    startY=e.clientY; dragging=true;
    card.style.transition='none';
    card.setPointerCapture?.(e.pointerId);
  });
  card.addEventListener('pointermove',e=>{
    if(!dragging)return;
    const dy=Math.max(0,e.clientY-startY);
    card.style.transform=`translateY(${dy}px)`;
  });
  const end=e=>{
    if(!dragging)return;
    const dy=e.clientY-startY;
    dragging=false; startY=null;
    if(dy>70){
      card.style.transition='transform .2s ease';
      card.style.transform='translateY(110%)';
      const sheet=$('doorSheet');
      sheet.classList.remove('open');
      sheet.setAttribute('aria-hidden','true');
      state.doorLeadId=null;
      state.doorSaving=false;
      clearTimeout(openDoorSheet._t);
      openDoorSheet._t=setTimeout(()=>{card.style.transition='';card.style.transform='';if(!sheet.classList.contains('open'))sheet.classList.add('hidden');},220);
      return;
    }
    card.style.transition='';
    card.style.transform='';
  };
  card.addEventListener('pointerup',end);
  card.addEventListener('pointercancel',end);
}
function nearestUnknocked(from){
  if(!from||!isCoords(from))return null;
  let best=null, bestD=Infinity;
  for(const l of state.leads){
    if(l.id===from.id||!isCoords(l)||leadStatus(l)!=='New')continue;
    const d=haversine(Number(from.lat),Number(from.lng),Number(l.lat),Number(l.lng));
    if(d<bestD){best=l; bestD=d;}
  }
  return best;
}
function openNextHouse(fromId){
  const from=state.leads.find(x=>x.id===fromId);
  const next=nearestUnknocked(from);
  dismissDoorToast();
  if(!next){toast('No un-knocked houses left nearby.');return;}
  state.map?.setView([Number(next.lat),Number(next.lng)],18,{animate:false});
  openDoorSheet(next.id);
}
async function undoDoorStatus(){
  const pending=state.doorUndo; if(!pending)return;
  state.doorUndo=null;
  $('toastActions').classList.add('hidden');
  const l=state.leads.find(x=>x.id===pending.id);
  if(!l||leadStatus(l)!==pending.to){toast('That door already changed.');return;}
  try{await persistLeadPatch(l,{status:pending.from});}
  catch{return;}
  renderAll();
  toast(`Restored · ${pending.from}`);
}
async function applyDoorStatus(id,status){
  const l=state.leads.find(x=>x.id===id); if(!l||state.doorSaving)return;
  if(!DOOR_STATUSES.includes(status))return;
  const previous=leadStatus(l);
  if(previous===status){renderAll();closeDoorSheet();toast(`Already ${status} · ${l.address}`);maybeAdvanceNav(id);return;}
  state.doorSaving=true;
  const buttons=[...$('doorSheetActions').querySelectorAll('button')];
  buttons.forEach(b=>{b.disabled=true;});
  const tapped=buttons.find(b=>b.dataset.doorStatus===status);
  const label=tapped?.querySelector('span:last-child');
  if(label) label.textContent='Saving…';
  try{await persistLeadPatch(l,{status});}
  catch{state.doorSaving=false;buttons.forEach(b=>{b.disabled=false;});if(label) label.textContent=status;return;}
  state.doorSaving=false;
  renderAll();
  closeDoorSheet();
  toastDoorResult(l, previous, status);
  maybeAdvanceNav(id);
}
function toastDoorResult(lead, fromStatus, toStatus){
  const el=$('toast'); if(!el)return;
  $('toastText').textContent=`${toStatus} · ${lead.address}`;
  $('toastActions').classList.remove('hidden');
  state.doorUndo={id:lead.id, from:fromStatus, to:toStatus};
  el.classList.add('show');
  clearTimeout(toast._t);
  toast._t=setTimeout(()=>{el.classList.remove('show'); $('toastActions').classList.add('hidden'); state.doorUndo=null; syncListOverlay();},5000);
  syncListOverlay();
}
function dismissDoorToast(){
  clearTimeout(toast._t);
  $('toast')?.classList.remove('show');
  $('toastActions')?.classList.add('hidden');
  state.doorUndo=null;
  syncListOverlay();
}

async function persistLeadPatch(l,patch){
  const previous=leadStatus(l);
  const normalized={...patch};
  if('assignedRepId' in normalized){normalized.assigned_rep_id=normalized.assignedRepId;delete normalized.assignedRepId;}
  if('roofAgeYears' in normalized){normalized.roof_age_years=normalized.roofAgeYears;delete normalized.roofAgeYears;}
  if('roofAgeVerified' in normalized){normalized.roof_age_verified=normalized.roofAgeVerified;delete normalized.roofAgeVerified;}
  Object.assign(l,normalized);
  l.assignedRepId=l.assigned_rep_id??l.assignedRepId??null;
  l.roofAgeYears=l.roof_age_years??l.roofAgeYears??null;
  l.roofAgeVerified=l.roof_age_verified??l.roofAgeVerified??false;
  if(state.mode==='cloud'){
    const payload={...normalized,updated_at:nowISO(),updated_by:state.currentRep.id};
    const {error}=await state.supabase.from('leads').update(payload).eq('id',l.id);
    if(error){alert(error.message);throw error;}
    if(normalized.status&&previous!==normalized.status){
      await logActivity(l.id,'status_changed',{from_status:previous,to_status:normalized.status});
      window.TrueNorthField?.captureDoorStatus?.({leadId:l.id,status:normalized.status});
    }
  }else{
    const meta=JSON.parse(localStorage.getItem('tnrc2:leadsMeta')||'{}'); meta[l.id]={status:l.status,owner:leadOwnerName(l),notes:l.notes||''}; localStorage.setItem('tnrc2:leadsMeta',JSON.stringify(meta)); saveLocal(l,meta[l.id]);
    if(normalized.status&&previous!==normalized.status)localAppendActivity({lead_id:l.id,actor_id:'local',action:'status_changed',metadata:{from_status:previous,to_status:normalized.status},created_at:nowISO()});
  }
}

function openLead(id, options={}){
  if(useDoorSheet() && !options.full){openDoorSheet(id);return;}
  const l=state.leads.find(x=>x.id===id);if(!l)return;
  state.active=id;
  const appt=state.appointments.find(a=>a.lead_id===id&&a.stage!=='Cancelled');
  const notes=l.notes||localSaved(l).notes||'';
  const reps=state.reps.slice().sort((a,b)=>a.name.localeCompare(b.name));
  $('drawerContent').innerHTML=`<div class="drawerTop" data-lead-id="${esc(l.id)}"><div><div class="eyebrow">FIELD RECORD</div><h2>${esc(l.name||'Property lead')}</h2><div class="drawerAddr">${esc(l.address)}<br>${esc(l.city)}, ${esc(l.state)} ${esc(l.zip)}</div></div><span class="bigScore">${scoreLead(l)}</span></div>
    <section class="drawerSection" data-tn-panel="lead-details" data-tn-rank="primary"><h3>House details</h3><div class="detailGrid"><div><small>Source</small><b>${esc(l.source)}</b></div><div><small>Priority</small><b>${esc(l.priority||'Standard')}</b></div><div><small>Built</small><b>${esc(l.year_built??l.yearBuilt??'Unknown')}</b></div><div><small>Mapped</small><b>${esc(geocodeLabel(l))}</b></div></div>
    <div class="drawerActions"><button id="drawerMaps" class="darkBtn">Open Google Maps</button><button id="drawerDir" class="outlineBtn">Directions</button></div>
    <div class="fieldActions"><button data-qstatus="Knocked">Knocked</button><button data-qstatus="No Answer">No answer</button><button data-qstatus="Interested">Interested</button><button data-qstatus="Not Interested">Not interested</button></div>
    <label>Sales status</label><select id="dStatus">${STATUS_OPTIONS.map(x=>`<option value="${esc(x)}" ${leadStatus(l)===x?'selected':''}>${esc(x)}</option>`).join('')}</select>
    <label>Assigned rep</label><select id="dOwner"><option value="">Unassigned</option>${reps.map(r=>`<option value="${esc(r.id)}" ${l.assignedRepId===r.id?'selected':''}>${esc(r.name)} · ${esc(roleLabel(r.role))}</option>`).join('')}</select>
    <div class="verifiedGrid"><label>Roof age (verified)</label><input id="dRoofAge" type="number" min="0" max="100" value="${esc(l.roof_age_years??l.roofAgeYears??'')}" placeholder="e.g. 16"><label><input id="dRoofVerified" type="checkbox" ${l.roof_age_verified||l.roofAgeVerified?'checked':''}> verified</label></div>
    <label>Notes</label><textarea id="dNotes" placeholder="Homeowner response, roof condition, next action…">${esc(notes)}</textarea>
    <button id="saveLeadBtn" class="saveBtn">Save field result</button></section>
    <div class="drawerSection"><div class="sectionTitle">Appointment handoff</div>${appt?`<div class="apptCard"><b>${esc(formatDate(appt.scheduled_at))}</b><div>Salesperson: ${esc(appt.salesperson?.name||state.reps.find(r=>r.id===appt.salesperson_id)?.name||'Unassigned')}</div><span class="status ${statusClass(appt.stage)}">${esc(appt.stage)}</span><button id="editApptBtn">${handoffPermissions({role:handoffActor().role, repId:handoffActor().repId, appointment:appt}).notes||handoffPermissions({role:handoffActor().role, repId:handoffActor().repId, appointment:appt}).assign?'Open handoff':'View handoff'}</button></div>`:`<a class="outlineBtn" href="/setter.html?lead=${encodeURIComponent(l.id)}">Inspection form</a>`}</div>`;
  $('drawer').classList.remove('hidden');
  $('drawerMaps').onclick=()=>openMaps(l); $('drawerDir').onclick=()=>openDirections(l);
  if($('drawerSetter')) $('drawerSetter').onclick=()=>{location.href=`/setter.html?lead=${encodeURIComponent(l.id)}`;};
  $('drawer').querySelectorAll('[data-qstatus]').forEach(btn=>btn.onclick=()=>quickStatus(l.id,btn.dataset.qstatus,true));
  $('saveLeadBtn').onclick=()=>saveLead(l);
  $('editApptBtn')?.addEventListener('click',()=>openAppointmentForm(l,appt));
}
function closeDrawer(){$('drawer').classList.add('hidden');state.active=null;}
async function saveLead(l){
  const status=$('dStatus').value, repId=$('dOwner').value||null, roofAge=$('dRoofAge').value?Number($('dRoofAge').value):null, roofVerified=$('dRoofVerified').checked, notes=$('dNotes').value;
  try{await persistLeadPatch(l,{status,assigned_rep_id:repId,assignedRepId:repId,roof_age_years:roofAge,roofAgeYears:roofAge,roof_age_verified:roofVerified,roofAgeVerified:roofVerified,notes});}
  catch{return}
  closeDrawer();renderAll();
  if(status==='Appointment'){location.href=`/setter.html?lead=${encodeURIComponent(l.id)}`;return;}
  toast('Field result saved');
}

async function logActivity(leadId,action,metadata={}){
  if(state.mode==='cloud'){const {data,error}=await state.supabase.from('lead_activity').insert({lead_id:leadId,actor_id:state.currentRep.id,action,metadata}).select('id,lead_id,actor_id,action,metadata,created_at').single();if(!error&&data)state.activities.unshift(data)}else localAppendActivity({lead_id:leadId,actor_id:'local',action,metadata,created_at:nowISO()});
}
function localAppendActivity(a){state.activities.unshift(a);localStorage.setItem('tnrc2:activities',JSON.stringify(state.activities.slice(0,4000)))}

function openMaps(l){window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(l.full_address||l.fullAddress||addressOf(l))}`,'_blank','noopener')}
function openDirections(l){window.open(`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(l.full_address||l.fullAddress||addressOf(l))}&travelmode=${state.routeMode}`,'_blank','noopener')}
function addressOf(l){return [l.address,l.city,l.state,l.zip].filter(Boolean).join(', ')}

function openRoutePanel(){
  if(window.tnFeatureAllowed?.('routes')===false)return;
  if(useDoorSheet())setListSheet('sheet-full');
  setRouteTrayCollapsed(false);
  $('selectedCountRoute').textContent=fmt(state.selected.size);
  $('optimizeRouteBtn').disabled=state.selected.size===0||!!state.routeBuilding;
  $('optimizeRouteBtn').hidden=!state.routeStops.length;
  $('openGoogleRouteBtn').disabled=!state.routeStops.length;
  $('routePanel').classList.remove('hidden');
}
function closeRoutePanel(){const wasOpen=!$('routePanel').classList.contains('hidden');$('routePanel').classList.add('hidden');if(wasOpen)$('routeTrayBtn').focus()}
function routeBuildKey(){return `${state.routeMode}:${$('routeCount').value}:${[...state.selected].sort().join(',')}`;}
function publishRouteState(){
  const tray=$('routeTray');if(!tray)return;
  tray.dataset ||= {};
  tray.dataset.routeReady=String(!!state.routeStops?.length&&!state.routeBuilding&&state.routeBuildKey===routeBuildKey());
  tray.dataset.routeBuilding=String(!!state.routeBuilding);
  tray.dataset.routeStopCount=String(state.routeStops?.length||0);
}
function invalidateBuiltRoute(){
  state.routeRequestSeq=(state.routeRequestSeq||0)+1;
  state.routeBuildKey='';state.routeStops=[];state.routeGeometry=null;
  if(state.navigating)endNavigation('');
  if(state.routeLine&&state.map){state.map.removeLayer(state.routeLine);state.routeLine=null;}
  $('routeDistance').textContent='';$('routeTrayStats').textContent='';
  $('optimizeRouteBtn').textContent='Build route';
  renderRouteStops();
  publishRouteState();
}
async function optimizeAndDrawRoute(){
  if(state.routeBuilding || window.tnFeatureAllowed?.('routes')===false)return;
  openRoutePanel();
  const raw=[...state.selected].map(id=>state.leads.find(l=>l.id===id)).filter(Boolean);
  const mapped=raw.filter(isCoords); const max=Number($('routeCount').value||25); const leads=mapped.slice(0,max);
  if(!leads.length){alert('Select mapped houses first. Unmapped addresses need geocoding before they can be optimized.');return}
  if(raw.length>max)$('routeWarning').textContent=`Using the first ${max} mapped selections.`;else if(mapped.length<raw.length)$('routeWarning').textContent=`${raw.length-mapped.length} selected houses have no coordinates yet.`;else $('routeWarning').textContent='';
  const start=state.currentLocation||{lat:leads[0].lat,lng:leads[0].lng};
  state.routeBuilding=true;state.routeBuildKey=routeBuildKey();
  $('routeTrayBtn').disabled=true;$('optimizeRouteBtn').disabled=true;
  state.routeStops=nearestNeighbor2Opt(leads,start);
  publishRouteState();
  renderRouteStops();
  $('routeDistance').textContent='Optimizing…';
  try{await fetchRoadRoute(start,state.routeStops);}
  finally{state.routeBuilding=false;updateSelectedBadge();$('optimizeRouteBtn').textContent=state.routeStops.length?'Rebuild route':'Build route';}
}
async function fetchRoadRoute(start,stops){
  const request=state.routeRequestSeq=(state.routeRequestSeq||0)+1;
  try{const points=[start,...stops].map(p=>({lat:p.lat,lng:p.lng}));const r=await fetch('/api/route',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({profile:osrmProfile(state.routeMode),coordinates:points})});const data=await r.json();if(!r.ok)throw new Error(data.error||'Route service failed');
    if(request!==state.routeRequestSeq)return;
    if(Array.isArray(data.order)&&data.order.length===stops.length){const ordered=data.order.map(i=>stops[i-1]).filter(Boolean);if(ordered.length===stops.length){state.routeStops=ordered;renderRouteStops();}}
    state.routeGeometry=data.geometry||null;
    drawRoutePreview(!state.navigating);
    const summary=`${fmtDistance(data.distance/1609.344)} · ${fmtDuration(data.duration)} · ${state.routeMode==='walking'?'walking':'driving'}`;
    $('routeDistance').textContent=`${summary} · road-network optimized`;
    $('routeTrayStats').textContent=summary;
  }catch(e){if(request!==state.routeRequestSeq)return;state.routeGeometry=null;drawRoutePreview();$('routeDistance').textContent=`Road router unavailable · ≈ ${fmtDistance(routeHaversineDistance(start,stops))}`;$('routeTrayStats').textContent=`≈ ${fmtDistance(routeHaversineDistance(start,stops))} straight line`;console.warn(e)}
  liftMapChrome();
}
function routeHaversineDistance(start,stops){let total=0,cur=start;for(const p of stops){total+=haversine(cur.lat,cur.lng,p.lat,p.lng);cur=p}return total}
function fmtDistance(miles){const n=Number(miles||0);return n<10?`${n.toFixed(1)} mi`:`${Math.round(n)} mi`}
function fmtDuration(sec){const m=Math.round(Number(sec||0)/60);return m<60?`${m} min`:`${Math.floor(m/60)}h ${m%60}m`}
function nearestNeighbor2Opt(leads,start){
  const remaining=leads.slice(); const out=[]; let cur=start;
  while(remaining.length){let bestIdx=0,best=Infinity;remaining.forEach((l,i)=>{const d=haversine(cur.lat,cur.lng,l.lat,l.lng);if(d<best){best=d;bestIdx=i}});const next=remaining.splice(bestIdx,1)[0];out.push(next);cur=next}
  if(out.length<4)return out;
  let improved=true;let loops=0;
  while(improved&&loops++<6){improved=false;for(let i=0;i<out.length-2;i++){for(let j=i+2;j<out.length;j++){const a=out[i],b=out[i+1],c=out[j],d=out[j+1];const before=haversine(a.lat,a.lng,b.lat,b.lng)+(d?haversine(c.lat,c.lng,d.lat,d.lng):0);const after=haversine(a.lat,a.lng,c.lat,c.lng)+(d?haversine(b.lat,b.lng,d.lat,d.lng):0);if(after+0.000001<before){const rev=out.slice(i+1,j+1).reverse();out.splice(i+1,rev.length,...rev);improved=true}}}}
  return out;
}
function drawRoutePreview(fit=true){
  if(state.routeLine){state.map.removeLayer(state.routeLine);state.routeLine=null}
  if(!state.routeStops?.length||!state.map)return;
  if(state.navigating){drawNavOverlay();return}
  if(state.routeGeometry)state.routeLine=L.geoJSON(state.routeGeometry,{style:{color:'#0267ee',weight:5,opacity:.78}}).addTo(state.map);
  else{const coords=state.routeStops.map(l=>[Number(l.lat),Number(l.lng)]);state.routeLine=L.polyline(coords,{weight:5,opacity:.75,dashArray:'8 7'}).addTo(state.map);}
  if(fit){try{state.map.fitBounds(state.routeLine.getBounds().pad(.12));}catch{}}
}
function renderRouteStops(){
  $('openGoogleRouteBtn').disabled=!state.routeStops.length;
  $('optimizeRouteBtn').hidden=!state.routeStops.length;
  $('routeStops').innerHTML=state.routeStops.map((l,i)=>`<div class="routeStop"><span>${i+1}</span><div><b>${esc(l.address)}</b><small>${esc(l.city)} · ${scoreLead(l)} pts</small></div><button type="button" aria-label="Remove ${esc(l.address || 'stop')} from route" data-route-lead="${esc(l.id)}">×</button></div>`).join('')||'<div class="empty">No route yet.</div>';
  $('routeStops').querySelectorAll('[data-route-lead]').forEach(btn=>btn.onclick=()=>{state.selected.delete(btn.dataset.routeLead);invalidateBuiltRoute();updateSelectedBadge();refreshSelectedMarkers();renderWorkList()});
}
function openGoogleRouteBlocks(){
  if(!state.routeStops.length){alert('Optimize a route first.');return}
  const chunks=[];for(let i=0;i<state.routeStops.length;i+=9)chunks.push(state.routeStops.slice(i,i+9));
  const travel=googleTravelMode(state.routeMode);
  chunks.forEach((chunk,idx)=>{const origin=idx===0?(state.currentLocation?`${state.currentLocation.lat},${state.currentLocation.lng}`:addressOf(chunk[0])):addressOf(state.routeStops[idx*9-1]);const destination=addressOf(chunk.at(-1));const mids=chunk.slice(0,-1).map(addressOf);const u=`https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(origin)}&destination=${encodeURIComponent(destination)}${mids.length?`&waypoints=${encodeURIComponent(mids.join('|'))}`:''}&travelmode=${encodeURIComponent(travel)}`;window.open(u,'_blank','noopener')});
}
function openAppleRoute(stops=state.routeStops){
  const points=(stops||[]).filter(isCoords);
  if(!points.length){toast('Optimize a route first.');return}
  window.open(appleDirectionsUrl(state.currentLocation, points, state.routeMode),'_blank','noopener');
}

function showHandoffField(id, on){
  const el=$(id); if(!el) return;
  el.classList.toggle('hidden', !on);
  el.querySelectorAll('input,select,textarea').forEach(input=>{input.disabled=!on;});
}
function toDatetimeLocal(value){
  const date=new Date(value);
  if(Number.isNaN(date.getTime())) return '';
  const pad=n=>String(n).padStart(2,'0');
  return `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}
function openAppointmentForm(l,appt=null){
  if(!appt){location.href=`/setter.html?lead=${encodeURIComponent(l.id)}`;return;}
  const actor=handoffActor();
  const perms=handoffPermissions({role:actor.role, repId:actor.repId, appointment:appt});
  $('appointmentModal').classList.remove('hidden');
  $('appointmentTitle').textContent='Inspection';
  const salesName=state.reps.find(r=>r.id===appt.salesperson_id)?.name||appt.salesperson?.name||'Unassigned';
  $('handoffSummary').innerHTML=`<b>${esc(l.name||'Inspection')}</b><div>${esc(addressOf(l))}</div><div>${esc(formatDate(appt.scheduled_at))} · ${esc(appt.stage)}</div><div>Sales rep: ${esc(salesName)}</div>`;
  const viewOnly=!perms.notes&&!perms.assign&&!perms.photos&&!perms.complete&&!perms.reopen;
  $('handoffAccessNote').textContent=viewOnly?(isHandoffSetter(actor.role)?'Appointment setters can view handoffs only.':'You can view this handoff only.'):'';
  $('appLeadId').value=l.id;
  $('appId').value=appt.id||'';
  $('appScheduled').value=appt.scheduled_at?toDatetimeLocal(appt.scheduled_at):'';
  $('appStage').value=appt.stage||'Scheduled';
  $('appSalesperson').innerHTML='<option value="">Unassigned</option>'+state.reps.filter(r=>['salesperson','manager','admin'].includes(r.role)).map(r=>`<option value="${esc(r.id)}" ${appt.salesperson_id===r.id?'selected':''}>${esc(r.name)} · ${esc(roleLabel(r.role))}</option>`).join('');
  $('appNotes').value=appt.notes||'';
  showHandoffField('appWhenLabel', perms.schedule);
  showHandoffField('appSalesLabel', perms.assign);
  showHandoffField('appStageLabel', perms.assign);
  showHandoffField('appNotesLabel', perms.notes);
  showHandoffField('appPhotoLabel', perms.photos);
  $('completeHandoffBtn')?.classList.toggle('hidden', !perms.complete);
  $('reopenHandoffBtn')?.classList.toggle('hidden', !perms.reopen);
  $('saveHandoffBtn')?.classList.toggle('hidden', !(perms.notes||perms.assign||perms.schedule));
  const receiptOk=Boolean(canUploadReceipt({role:actor.role, repId:actor.repId, leadId:l.id, appointments:[appt]}).ok);
  $('handoffReceipt')?.classList.toggle('hidden', !receiptOk);
  if($('handoffReceiptError')) $('handoffReceiptError').textContent='';
  if($('appPhoto')) $('appPhoto').value='';
  paintHandoffPhotos(appt);
}
async function saveAppointmentFromForm(e){e.preventDefault();
  if($('saveHandoffBtn')?.classList.contains('hidden')) return;
  const before=state.appointments.find(a=>String(a.id)===String($('appId').value));
  if(!before){alert('Open an inspection from the handoff queue.');return;}
  const actor=handoffActor();
  const patch={};
  if(!$('appNotesLabel')?.classList.contains('hidden')) patch.notes=$('appNotes').value.trim();
  if(!$('appSalesLabel')?.classList.contains('hidden')) patch.salesperson_id=$('appSalesperson').value||null;
  if(!$('appWhenLabel')?.classList.contains('hidden') && $('appScheduled').value) patch.scheduled_at=new Date($('appScheduled').value).toISOString();
  if(!$('appStageLabel')?.classList.contains('hidden')) patch.stage=$('appStage').value;
  const check=validateHandoffPatch({role:actor.role, repId:actor.repId, before, patch});
  if(check.error){alert(check.error);return;}
  await applyHandoffPatch(before, patch);
}
async function completeHandoff(){
  const before=state.appointments.find(a=>String(a.id)===String($('appId').value));
  if(!before) return;
  const actor=handoffActor();
  const check=validateHandoffPatch({role:actor.role, repId:actor.repId, before, patch:{stage:'Completed'}});
  if(check.error){alert(check.error);return;}
  await applyHandoffPatch(before, {stage:'Completed'});
}
async function reopenHandoff(){
  const before=state.appointments.find(a=>String(a.id)===String($('appId').value));
  if(!before) return;
  const actor=handoffActor();
  const check=validateHandoffPatch({role:actor.role, repId:actor.repId, before, patch:{stage:'Scheduled'}});
  if(check.error){alert(check.error);return;}
  await applyHandoffPatch(before, {stage:'Scheduled'});
}
async function applyHandoffPatch(before, patch){
  if(state.mode==='cloud'){
    const result=await state.supabase.from('appointments').update(patch).eq('id', before.id).select('id,lead_id,canvasser_id,salesperson_id,scheduled_at,stage,notes').single();
    if(result.error){alert(result.error.message);return;}
    const idx=state.appointments.findIndex(a=>a.id===before.id);
    if(idx>=0) state.appointments[idx]={...state.appointments[idx], ...result.data};
  }else{
    const idx=state.appointments.findIndex(a=>a.id===before.id);
    if(idx>=0) state.appointments[idx]={...state.appointments[idx], ...patch};
    localStorage.setItem('tnrc2:appointments', JSON.stringify(state.appointments));
  }
  $('appointmentModal').classList.add('hidden');
  renderAll();
}
async function addHandoffPhoto(file){
  const before=state.appointments.find(a=>String(a.id)===String($('appId').value));
  if(!before||!file) return;
  const actor=handoffActor();
  const check=assertHandoffPhoto({role:actor.role, repId:actor.repId, appointment:before});
  if(check.error){alert(check.error);return;}
  const lead=state.leads.find(x=>x.id===before.lead_id);
  if(state.mode!=='cloud'){
    state.handoffPhotos=state.handoffPhotos||[];
    state.handoffPhotos.push({id:`local-photo-${Date.now()}`, lead_id:before.lead_id, appointment_id:before.id, url:URL.createObjectURL(file), caption:file.name});
    paintHandoffPhotos(before);
    if($('appPhoto')) $('appPhoto').value='';
    return;
  }
  const path=`${before.lead_id}/${crypto.randomUUID()}.jpg`;
  const upload=await state.supabase.storage.from('lead-photos').upload(path, file, {contentType:file.type||'image/jpeg', upsert:false});
  if(upload.error){alert(upload.error.message);return;}
  const inserted=await state.supabase.from('lead_photos').insert({
    lead_id:before.lead_id,
    appointment_id:before.id,
    storage_path:path,
    uploaded_by:state.currentRep.id,
    address_snapshot:lead?addressOf(lead):'',
    caption:''
  }).select('id,lead_id,appointment_id,storage_path,caption').single();
  if(inserted.error){
    alert(/appointment_id|schema cache|column/i.test(inserted.error.message)?'Run supabase/migrations/20261008_inspection_handoff.sql in the Supabase SQL editor, then try again.':inserted.error.message);
    return;
  }
  const signed=await state.supabase.storage.from('lead-photos').createSignedUrl(path, 60*60);
  state.handoffPhotos=state.handoffPhotos||[];
  state.handoffPhotos.push({...inserted.data, url:signed.data?.signedUrl||''});
  paintHandoffPhotos(before);
  if($('appPhoto')) $('appPhoto').value='';
}
function paintHandoffPhotos(appointment){
  const box=$('handoffPhotos'); if(!box) return;
  const rows=(state.handoffPhotos||[]).filter(photo=>photo.appointment_id===appointment.id);
  box.innerHTML=rows.map(photo=>photo.url?`<img alt="${esc(photo.caption||'Inspection photo')}" src="${esc(photo.url)}">`:'').join('');
  box.classList.toggle('hidden', !rows.length);
}
function openGeneralReceipt(){
  const actor=handoffActor();
  const decision=canUploadReceipt({role:actor.role, repId:actor.repId, leadId:null, appointments:state.appointments});
  if(!decision.ok){alert(decision.error);return;}
  $('receiptForm')?.reset();
  if($('receiptLeadId')) $('receiptLeadId').value='';
  if($('receiptError')) $('receiptError').textContent='';
  if($('receiptTitle')) $('receiptTitle').textContent='Upload receipt';
  if($('receiptContext')) $('receiptContext').textContent='This receipt is not tied to an inspection. Admins see it in Document Library → Receipts.';
  $('receiptModal')?.classList.remove('hidden');
}
async function saveGeneralReceipt(event){
  event.preventDefault();
  await uploadReceipt({
    file:$('receiptFile')?.files?.[0],
    amount:$('receiptAmount')?.value,
    vendor:$('receiptVendor')?.value,
    recordDate:$('receiptDate')?.value,
    note:$('receiptNote')?.value,
    leadId:null,
    errorEl:$('receiptError'),
    onSaved(){$('receiptModal')?.classList.add('hidden');}
  });
}
async function uploadReceipt({file, amount, vendor, recordDate, note, leadId, errorEl, onSaved}={}){
  const actor=handoffActor();
  const decision=canUploadReceipt({role:actor.role, repId:actor.repId, leadId:leadId||null, appointments:state.appointments});
  if(!decision.ok){if(errorEl) errorEl.textContent=decision.error; return;}
  if(!file){if(errorEl) errorEl.textContent='Choose a photo or PDF.'; return;}
  const lead=leadId?state.leads.find(x=>x.id===leadId):null;
  try{
    const store=await import('./tn-files/store.js');
    const ctx=state.mode==='cloud'
      ? {mode:'cloud', sb:state.supabase, rep:state.currentRep}
      : {mode:'local', sb:null, rep:{id:actor.repId, role:actor.role, name:'Sales rep'}};
    await store.saveReceipt(ctx, {
      file,
      amount,
      vendor,
      record_date:recordDate,
      note,
      lead_id:leadId||null,
      address_snapshot:lead?addressOf(lead):''
    });
    if(errorEl) errorEl.textContent='Uploaded. Admins can see it in Receipts.';
    if($('handoffReceiptFile')) $('handoffReceiptFile').value='';
    await refreshMyReceipts();
    onSaved?.();
  }catch(error){
    const message=String(error?.message||error||'Could not upload that receipt.');
    if(errorEl) errorEl.textContent=/row-level security|42501|permission/i.test(message)?'Only the assigned sales rep can upload this receipt. Apply supabase/migrations/20261008_inspection_handoff.sql if this is a new database.':message;
  }
}
async function refreshMyReceipts(){
  const list=$('myReceiptList'); if(!list) return;
  const actor=handoffActor();
  if(actor.role!=='salesperson'){list.innerHTML='';return;}
  let rows=[];
  try{
    if(state.mode==='cloud' && state.supabase){
      const {data, error}=await state.supabase.from('receipt_records').select('id,uploaded_by,file_name,amount,vendor,record_date,lead_id,address_snapshot,note,created_at').order('created_at',{ascending:false}).limit(100);
      if(!error) rows=data||[];
    }else{
      const store=await import('./tn-files/store.js');
      rows=await store.listReceipts({mode:'local'});
    }
  }catch{rows=[];}
  const mine=rows.filter(row=>canSeeReceipt({role:actor.role, repId:actor.repId, receipt:row}));
  list.innerHTML=mine.length?mine.map(row=>{
    const bits=[row.vendor, row.amount!=null&&row.amount!==''?`$${row.amount}`:'', row.record_date, row.address_snapshot].filter(Boolean).join(' · ');
    return `<div class="receiptRow"><b>${esc(row.file_name||'Receipt')}</b><div>${esc(bits||'No details')}</div>${row.note?`<div>${esc(row.note)}</div>`:''}</div>`;
  }).join(''):'<div class="empty">No receipts uploaded yet.</div>';
}
function openAppointment(id){const a=state.appointments.find(x=>String(x.id)===String(id));if(!a)return;const l=state.leads.find(x=>x.id===a.lead_id)||{id:a.lead_id,name:'Inspection',address:'',city:'',state:'',zip:''};openAppointmentForm(l,a);}
async function copyCurrentHandoff(){
  const id=$('appLeadId').value; const l=state.leads.find(x=>x.id===id);if(!l)return;
  const text=`True North Restorations — Sales Handoff\nHomeowner: ${l.name||'Property lead'}\nAddress: ${addressOf(l)}\nAppointment: ${formatDate($('appScheduled').value)}\nSalesperson: ${state.reps.find(r=>r.id===$('appSalesperson').value)?.name||'Unassigned'}\nNotes: ${$('appNotes').value||'—'}`;
  try{await navigator.clipboard.writeText(text);$('copyHandoffBtn').textContent='Copied';setTimeout(()=>$('copyHandoffBtn').textContent='Copy handoff',1200)}catch{alert(text)}
}

function switchTab(tab,{toggle=false}={}){
  const btn=tab==='handoffs'||tab==='team'?$('tab'+tab.charAt(0).toUpperCase()+tab.slice(1)):null;
  const panel=tab==='handoffs'?$('handoffPanel'):tab==='team'?$('teamPanel'):null;
  const wasOpen=!!btn?.classList.contains('active');
  document.querySelectorAll('.mapInfoTabs .tab').forEach(x=>x.classList.remove('active'));
  $('handoffPanel')?.classList.add('hidden');
  $('teamPanel')?.classList.add('hidden');
  if(!panel||(toggle&&wasOpen))return;
  setInfoOpen(true);
  btn?.classList.add('active');
  panel.classList.remove('hidden');
  if(tab==='handoffs') refreshMyReceipts();
}

function openAdmin(){
  $('adminModal').classList.remove('hidden');
  const accounts=$('adminAccountsLink');
  if(accounts){
    accounts.href='/admin#accounts';
    accounts.classList.toggle('hidden', !canOpenManagement({email:state.user?.email, rep:state.currentRep, adminEmails:state.config?.adminEmails}));
  }
  $('adminCloudStatus').textContent=state.mode==='cloud'?`Connected as ${state.currentRep?.name||state.user?.email}`:'Local device mode';
  $('adminLeadCount').textContent=fmt(state.leads.length); $('adminMappedCount').textContent=fmt(state.leads.filter(isCoords).length); $('adminTerritoryCount').textContent=fmt(state.territories.length);
  renderTerritoryAdmin();
}
function renderTerritoryAdmin(){
  const cities=[...new Set(state.leads.map(l=>l.city).filter(Boolean))].sort((a,b)=>a.localeCompare(b));
  $('territoryAdmin').innerHTML=cities.slice(0,260).map(city=>{const t=state.territories.find(x=>x.name===city)||{};return `<div class="territoryRow"><div><b>${esc(city)}</b><small>${fmt(state.leads.filter(l=>l.city===city).length)} leads</small></div><select data-territory="${esc(city)}"><option value="">Unassigned</option>${state.reps.map(r=>`<option value="${esc(r.id)}" ${t.assigned_rep_id===r.id?'selected':''}>${esc(r.name)}</option>`).join('')}</select></div>`}).join('');
  $('territoryAdmin').querySelectorAll('[data-territory]').forEach(el=>el.onchange=()=>saveTerritoryAssignment(el.dataset.territory,el.value||null));
}
async function saveTerritoryAssignment(city,repId){
  const existing=state.territories.find(t=>t.name===city);const center=state.centers?.[city];
  const row={id:existing?.id||crypto.randomUUID(),name:city,city,assigned_rep_id:repId,center_lat:center?.[0]??null,center_lng:center?.[1]??null,color:existing?.color||null};
  if(state.mode==='cloud'){const {data,error}=await state.supabase.from('territories').upsert(row,{onConflict:'name'}).select('*').single();if(error){alert(error.message);return}const idx=state.territories.findIndex(t=>t.name===city);if(idx>=0)state.territories[idx]=data;else state.territories.push(data)}else{const idx=state.territories.findIndex(t=>t.name===city);if(idx>=0)state.territories[idx]=row;else state.territories.push(row);localStorage.setItem('tnrc2:territories',JSON.stringify(state.territories))}
  renderAll();
}

async function importLeadsToCloud(){
  if(state.mode!=='cloud'){alert('Configure Supabase and sign in as an admin/manager first.');return}
  if(!['admin','manager'].includes(state.currentRep.role)){alert('Admin/manager role required.');return}
  let local;
  try{ local=await fetchJSON('/data/leads.json'); }catch{ alert('The cloud lead list is already set up. The public lead file is no longer served, so there is nothing to import.'); return; }
  const total=local.length;let done=0;
  setAdminProgress(0,`Importing ${fmt(total)} source leads…`);
  for(let i=0;i<total;i+=400){const batch=local.slice(i,i+400).map(l=>({id:l.id,source:l.source,name:l.name,address:l.address,secondary_address:l.secondaryAddress||'',city:l.city,state:l.state,zip:l.zip,full_address:l.fullAddress,record_id:l.recordId||null,record_type:l.recordType||null,year_built:l.yearBuilt??null,priority:l.priority||null,owner_occupied:l.ownerOccupied||null,pdf_page:l.pdfPage??null,lat:l.lat??null,lng:l.lng??null,geocode_match:l.geocodeMatch??null}));const {error}=await state.supabase.from('leads').upsert(batch,{onConflict:'id',ignoreDuplicates:true});if(error){alert(`Import stopped: ${error.message}`);return}done+=batch.length;setAdminProgress(Math.round(done/total*100),`Imported ${fmt(done)} / ${fmt(total)}`)}
  await loadCloudData();renderAll();$('adminLeadCount').textContent=fmt(state.leads.length);$('adminMappedCount').textContent=fmt(state.leads.filter(isCoords).length);
  alert(`Cloud dataset initialized with ${fmt(state.leads.length)} leads.`);
}
async function syncTerritories(){
  if(state.mode!=='cloud'){alert('Cloud mode required.');return}
  const cities=[...new Set(state.leads.map(l=>l.city).filter(Boolean))];const rows=cities.map(city=>{const c=state.centers?.[city];return{name:city,city,center_lat:c?.[0]??null,center_lng:c?.[1]??null}});const {error}=await state.supabase.from('territories').upsert(rows,{onConflict:'name',ignoreDuplicates:true});if(error){alert(error.message);return}await loadCloudData();renderAll();openAdmin();
}
function setAdminProgress(p,msg){$('adminProgress').style.width=`${p}%`;$('adminProgressLabel').textContent=msg}

async function geocodeAll(){
  if(state.mode!=='cloud'){alert('Cloud mode required. Seed the shared database first.');return}
  const missing=state.leads.filter(l=>!isCoords(l)); if(!missing.length){alert('All current leads already have coordinates.');return}
  const batchSize=500;let done=0,matched=0;
  setAdminProgress(0,`Geocoding ${fmt(missing.length)} addresses…`);
  for(let i=0;i<missing.length;i+=batchSize){
    const batch=missing.slice(i,i+batchSize);
    const r=await fetch('/api/geocode',{method:'POST',headers:{'content-type':'application/json','authorization':`Bearer ${state.session.access_token}`},body:JSON.stringify({addresses:batch.map(l=>({id:l.id,address:l.address,city:l.city,state:l.state,zip:(l.zip||'').split('-')[0]}))})});
    const payload=await r.json();if(!r.ok)throw new Error(payload.error||`Geocode HTTP ${r.status}`);
    const updates=geocodeUpdates(payload.results);
    matched+=updates.length;done+=batch.length;
    if(updates.length){const {error}=await state.supabase.from('leads').upsert(updates,{onConflict:'id'});if(error)throw error;const by=new Map(updates.map(x=>[x.id,x]));state.leads.forEach(l=>{const u=by.get(l.id);if(u){l.lat=u.lat;l.lng=u.lng;l.geocode_match=u.geocode_match}})}
    setAdminProgress(Math.round(done/missing.length*100),`Geocoded ${fmt(done)} / ${fmt(missing.length)} · matched ${fmt(matched)}`);
  }
  renderAll();$('adminMappedCount').textContent=fmt(state.leads.filter(isCoords).length);alert(`Geocoding complete: ${fmt(matched)} matched, ${fmt(missing.length-matched)} unmatched.`);
}

function emptyStormPack(){return {radar:[],warnings:[],reports:[]}}
async function ensureStormMaps(force=false){
  if(state.stormPack&&!force)return state.stormPack;
  if(state.stormBusy&&!force)return state.stormPack;
  state.stormBusy=true;
  const mine=++state.stormToken;
  try{
    if(!force){
      const cached=readStormCache(sessionStorage);
      if(cached){
        state.stormPack=cached;
        if(mine===state.stormToken)syncStormOverlays();
        return cached;
      }
    }
    const response=await fetch('/api/storm-maps');
    if(!response.ok)throw new Error('storm maps unavailable');
    const data=await response.json();
    if(mine!==state.stormToken)return state.stormPack;
    const pack={
      radar:Array.isArray(data.radar)?data.radar:[],
      warnings:Array.isArray(data.warnings)?data.warnings:[],
      reports:Array.isArray(data.reports)?data.reports:[]
    };
    state.stormPack=pack;
    writeStormCache(sessionStorage, pack);
    syncStormOverlays();
  }catch(error){
    console.warn(error);
    if(mine===state.stormToken&&!state.stormPack)state.stormPack=emptyStormPack();
    if(mine===state.stormToken)syncStormOverlays();
  }finally{
    if(mine===state.stormToken)state.stormBusy=false;
  }
  return state.stormPack||emptyStormPack();
}
function syncStormOverlays(){
  if(!state.map)return;
  if(!state.stormPack){
    if(state.layerFlags.radar||state.layerFlags.warnings||state.layerFlags.reports) ensureStormMaps();
    return;
  }
  syncRadar(state.layerFlags.radar?state.stormPack.radar:[]);
  syncWarnings(state.layerFlags.warnings?state.stormPack.warnings:[]);
  syncReports(state.layerFlags.reports?state.stormPack.reports:[]);
}
function stopRadar(){
  clearInterval(state.radarTimer);state.radarTimer=null;
  (state.radarLayers||[]).forEach(layer=>layer.remove());
  state.radarLayers=[];state.radarSignature='';
}
function syncRadar(frames){
  const list=Array.isArray(frames)?frames.filter(frame=>frame?.url):[];
  const sig=list.map(frame=>`${frame.time}|${frame.url}`).join(',');
  if(!list.length){stopRadar();return;}
  if(sig===state.radarSignature&&state.radarLayers.length)return;
  stopRadar();
  state.radarSignature=sig;
  state.radarLayers=list.map((frame,index)=>L.tileLayer(frame.url,{
    pane:'radarPane',opacity:index===list.length-1?0.45:0,zIndex:index+1,maxZoom:20,updateWhenIdle:true,keepBuffer:2
  }).addTo(state.map));
  if(list.length<2)return;
  let cursor=list.length-1;
  state.radarTimer=setInterval(()=>{
    cursor=(cursor+1)%state.radarLayers.length;
    state.radarLayers.forEach((layer,index)=>layer.setOpacity(index===cursor?0.45:0));
  },700);
}
function warningPopup(warning){
  const lines=[`<b>${esc(warning.event||'Warning')}</b>`];
  if(warning.headline)lines.push(esc(warning.headline));
  if(warning.hail)lines.push(`Hail ${esc(warning.hail)}`);
  if(warning.wind)lines.push(`Wind ${esc(warning.wind)}`);
  if(warning.expiresLabel)lines.push(`Until ${esc(warning.expiresLabel)}`);
  return `<div class="stormPopup">${lines.join('<br>')}</div>`;
}
function syncWarnings(warnings){
  const list=Array.isArray(warnings)?warnings:[];
  const sig=list.map(warning=>warning.id).join('|');
  if(sig===state.warningSignature&&(list.length?state.warningLayer:!state.warningLayer))return;
  if(state.warningLayer){state.map.removeLayer(state.warningLayer);state.warningLayer=null;}
  state.warningSignature=sig;
  if(!list.length)return;
  state.warningLayer=L.geoJSON({type:'FeatureCollection',features:list.map(warning=>({type:'Feature',properties:warning,geometry:warning.geometry}))},{
    style:feature=>{
      const color=WARNING_COLORS[feature.properties?.kind]||WARNING_COLORS.thunderstorm;
      return {color,weight:2,fillColor:color,fillOpacity:.28};
    },
    onEachFeature:(feature,layer)=>layer.bindPopup(warningPopup(feature.properties))
  }).addTo(state.map);
}
function reportRadius(report){
  const size=Number(report.measure);
  if(report.kind==='hail')return Math.max(7,Math.min(16, (Number.isFinite(size)?size:1)*6));
  if(report.kind==='wind')return Math.max(7,Math.min(16, (Number.isFinite(size)?size:40)/8));
  return 11;
}
function syncReports(reports){
  const list=Array.isArray(reports)?reports:[];
  const sig=list.map(report=>`${report.kind}:${report.lat}:${report.lng}:${report.time}`).join('|');
  if(sig===state.reportSignature&&(list.length?state.reportLayer:!state.reportLayer))return;
  if(state.reportLayer){state.map.removeLayer(state.reportLayer);state.reportLayer=null;}
  state.reportSignature=sig;
  if(!list.length)return;
  const group=L.layerGroup();
  list.forEach(report=>{
    if(!Number.isFinite(Number(report.lat))||!Number.isFinite(Number(report.lng)))return;
    const color=report.kind==='torn'?WARNING_COLORS.tornado:report.kind==='wind'?WARNING_COLORS.wind:WARNING_COLORS.hail;
    const marker=L.circleMarker([Number(report.lat),Number(report.lng)],{radius:reportRadius(report),color:'#fff',weight:2,fillColor:color,fillOpacity:.95});
    const place=[report.location,report.county,report.state].filter(Boolean).join(', ');
    marker.bindPopup(`<div class="stormPopup"><b>${esc(reportMarkerText(report))}</b>${place?`<br>${esc(place)}`:''}</div>`);
    group.addLayer(marker);
  });
  state.reportLayer=group.addTo(state.map);
}
async function loadStorms(){
  const box=document.querySelector('[data-layer="warnings"]');
  if(box)box.checked=true;
  state.layerFlags.warnings=true;
  try{writeSavedLayers(localStorage,state.layerFlags);}catch{}
  await ensureStormMaps(true);
  const count=state.stormPack?.warnings?.length||0;
  toast(count?`Showing ${fmt(count)} warning areas.`:'No active warning areas right now.');
}
async function housesInStormArea(){
  const pack=await ensureStormMaps();
  const hits=housesInStorm(state.leads, pack?.warnings||[], pack?.reports||[]);
  if(!hits.length){toast(`No houses are inside a warning or within ${HAIL_MILES} miles of a hail report.`);return;}
  state.stormHouseIds=new Set(hits.map(lead=>lead.id));
  const ranked=hits.slice().sort((a,b)=>scoreLead(b)-scoreLead(a));
  state.selected.clear();
  const {chosen,leftOut}=pickRouteStops(ranked.map(lead=>lead.id), state.selected, ROUTE_STOP_LIMIT);
  chosen.forEach(id=>state.selected.add(id));
  const note=leftOut?`${fmt(hits.length)} houses in the storm area. ${fmt(chosen.length)} queued for the route.`:`${fmt(chosen.length)} storm-area houses queued for the route.`;
  $('routeTrayNote').textContent=note;
  $('routeWarning').textContent=leftOut?note:'';
  toast(note);
  renderAll();
  fitMapToScope(true);
  openRoutePanel();
}

function locate(){
  if(document.visibilityState==='hidden')return;
  if(!navigator.geolocation){alert('Browser location is unavailable.');return}
  const token=++locate._seq;
  navigator.geolocation.getCurrentPosition(pos=>{
    if(document.visibilityState==='hidden'||token!==locate._seq||!state.map)return;
    state.currentLocation={lat:pos.coords.latitude,lng:pos.coords.longitude};
    weatherApi().then(mod=>mod.setWeatherLocation(state.currentLocation)).catch(()=>{});
    if(state.userMarker)state.userMarker.remove();
    state.userMarker=L.marker([pos.coords.latitude,pos.coords.longitude]).addTo(state.map).bindPopup('You are here').openPopup();
    state.map.setView([pos.coords.latitude,pos.coords.longitude],16);
    renderWorkList();
  },()=>alert('Location permission was not granted.'),{enableHighAccuracy:true,maximumAge:0,timeout:10000});
}
locate._seq=0;

function updateSelectedBadge(){
  if(state.routeBuildKey && state.routeBuildKey!==routeBuildKey())invalidateBuiltRoute();
  publishRouteState();
  const prev=state.routeCountSeen;
  const n=state.selected.size;
  state.routeCountSeen=n;
  $('selectedCount').textContent=n;$('selectedCountRoute').textContent=n;$('routeTrayCount').textContent=n;$('mobileRouteCount').textContent=n;
  $('optimizeRouteBtn').disabled=n===0||!!state.routeBuilding;
  $('routeTrayBtn').disabled=n===0||!!state.routeBuilding;
  $('startRouteBtn').disabled=n===0||!!state.routeBuilding;
  $('clearRouteBtn').disabled=n===0;
  updateRouteTraySummary();
  if(shouldExpandRouteTray(prev,n))setRouteTrayCollapsed(false);
  else liftMapChrome();
}
function readRouteTrayCollapsed(){
  let saved=null;
  try{saved=localStorage.getItem(ROUTE_TRAY_KEY);}catch{}
  return routeTrayCollapsedByDefault({saved,phone:window.matchMedia('(max-width: 960px)').matches,houseCount:state.selected.size});
}
function updateRouteTraySummary(){
  const summary=routeTraySummary(state.selected.size,state.routeMode);
  const label=$('routeTrayCompact'); if(label)label.textContent=summary;
  const btn=$('routeTrayToggle'); if(!btn)return;
  const collapsed=$('routeTray')?.classList.contains('isCollapsed');
  btn.setAttribute('aria-label', collapsed?`${summary}. Show route tools`:`${summary}. Hide route tools`);
}
function setRouteTrayCollapsed(collapsed,{persist=true}={}){
  const tray=$('routeTray'); if(!tray)return;
  const on=!!collapsed;
  tray.classList.toggle('isCollapsed',on);
  if(!on&&useDoorSheet())setListSheet('sheet-full');
  document.documentElement.classList.remove('routeTrayStartCollapsed');
  const btn=$('routeTrayToggle');
  if(btn)btn.setAttribute('aria-expanded',on?'false':'true');
  if(persist){try{localStorage.setItem(ROUTE_TRAY_KEY,on?'1':'0');}catch{}}
  updateRouteTraySummary();
  liftMapChrome();
}
function applyAreaRoute(result){
  const stops=result?.stops||[];
  state.selected.clear();
  stops.forEach(lead=>state.selected.add(lead.id));
  invalidateBuiltRoute();
  const note=result?.capped
    ?`Route stop limit is ${ROUTE_STOP_LIMIT}. Queued ${fmt(stops.length)} houses; ${fmt(result.leftOut)} more in the area stayed off this route.`
    :(stops.length?`${fmt(stops.length)} houses inside the drawn area are on this route.`:'No actionable houses inside that area.');
  $('routeTrayNote').textContent=note;
  $('routeWarning').textContent=result?.capped?note:'';
  toast(note);
  updateSelectedBadge();
  refreshSelectedMarkers();
  renderWorkList();
  setRouteTrayCollapsed(false);
  if(!stops.length){state.routeGeometry=null;drawRoutePreview(false);return;}
  openRoutePanel();
}
function openRouteFromChrome(){
  if(window.tnFeatureAllowed?.('routes')===false)return;
  if(document.body.classList.contains('mapFocus'))toggleMapFocus();
  if(useDoorSheet())setListSheet('sheet-full');
  setRouteTrayCollapsed(false);
  $('routeTray').scrollIntoView({block:'nearest'});
  openRoutePanel();
}
function toggleSelected(id){
  if(window.tnFeatureAllowed?.('routes')===false)return;
  if(state.selected.has(id))state.selected.delete(id);else state.selected.add(id);
  document.querySelectorAll(`.rowCheck[data-id="${CSS.escape(id)}"]`).forEach(box=>{box.checked=state.selected.has(id)});
  updateSelectedBadge();refreshSelectedMarkers();syncRouteButtons(id);
}
function syncRouteButtons(id){
  const label=routeToggleLabel(state.selected.has(id));
  document.querySelectorAll(`[data-popup-route="${CSS.escape(id)}"]`).forEach(btn=>{btn.textContent=label});
  if(state.doorLeadId===id&&$('doorSheetRoute'))$('doorSheetRoute').textContent=label;
}
function refreshSelectedMarkers(){
  state.pinShown.forEach(id=>{
    const lead=state.leadsById.get(id);
    const marker=state.pinMarkers.get(id);
    if(lead&&marker) stylePin(marker, lead);
  });
}
function selectVisibleForRoute(){
  if(window.tnFeatureAllowed?.('routes')===false)return;
  const mapped=state.filtered.filter(isCoords);
  let inView=[];
  if(state.map){const bounds=state.map.getBounds();inView=mapped.filter(lead=>bounds.contains([Number(lead.lat),Number(lead.lng)]));}
  const pool=visibleRoutePool(inView,mapped).slice().sort((a,b)=>scoreLead(b)-scoreLead(a));
  const {chosen,leftOut}=pickRouteStops(pool.map(lead=>lead.id),state.selected,ROUTE_STOP_LIMIT);
  chosen.forEach(id=>state.selected.add(id));
  const note=leftOut?`Route stop limit is ${ROUTE_STOP_LIMIT}. Added ${fmt(chosen.length)} mapped houses; ${fmt(leftOut)} more stayed off this route.`:(chosen.length?`Added ${fmt(chosen.length)} mapped houses from the map.`:'No mapped houses in this view.');
  $('routeTrayNote').textContent=note;
  $('routeWarning').textContent=leftOut?note:'';
  toast(note);
  updateSelectedBadge();refreshSelectedMarkers();renderWorkList();
}
function clearRoute(){
  state.routeRequestSeq=(state.routeRequestSeq||0)+1;
  endNavigation('');
  areaDraw?.clearArea();
  state.selected.clear();state.stormHouseIds=null;state.routeStops=[];state.routeGeometry=null;
  $('routeWarning').textContent='';$('routeDistance').textContent='';$('routeTrayStats').textContent='';
  renderRouteStops();
  $('routeTrayNote').textContent='Select homes, then build an optimized route.';
  renderAll();
}
function setRouteMode(mode){
  const next=mode==='walking'?'walking':'driving';
  const changed=state.routeMode!==next;
  state.routeMode=next;
  if($('routeMode')&&$('routeMode').value!==next)$('routeMode').value=next;
  $('trayDrive').classList.toggle('isOn', next==='driving');
  $('trayDrive').setAttribute('aria-pressed', next==='driving'?'true':'false');
  $('trayWalk').classList.toggle('isOn', next==='walking');
  $('trayWalk').setAttribute('aria-pressed', next==='walking'?'true':'false');
  updateRouteTraySummary();
  if(changed)invalidateBuiltRoute();
}
function syncNavChoiceButton(){
  const saved=readNavChoice(localStorage.getItem(NAV_CHOICE_KEY));
  const btn=$('navChoiceBtn'); if(!btn)return;
  const labels={app:'In-app nav', google:'Google Maps', apple:'Apple Maps'};
  btn.classList.toggle('hidden', !saved);
  btn.textContent=saved?`Nav: ${labels[saved]}`:'Change nav app';
}
function openNavChoice(launch){
  state.navLaunch=launch;
  const apple=isAppleDevice(navigator.userAgent, navigator.maxTouchPoints);
  $('navApple').classList.toggle('hidden', !apple);
  $('navChoiceMode').textContent=state.routeMode==='walking'?'Walking. Google Maps and Apple Maps use Walk.':'Driving. Google Maps and Apple Maps use Drive.';
  $('navRemember').checked=Boolean(readNavChoice(localStorage.getItem(NAV_CHOICE_KEY)));
  $('navChoice').classList.remove('hidden');
}
function closeNavChoice(){$('navChoice').classList.add('hidden')}
function confirmNavChoice(choice){
  if($('navRemember').checked)localStorage.setItem(NAV_CHOICE_KEY, choice);
  else localStorage.removeItem(NAV_CHOICE_KEY);
  const launch=state.navLaunch;
  closeNavChoice();
  syncNavChoiceButton();
  if(launch)runNavChoice(choice);
  else toast($('navRemember').checked?`Saved. Next routes use ${choice==='app'?'in-app navigation':choice==='apple'?'Apple Maps':'Google Maps'}.`:'Next routes will ask again.');
}
async function startRoute(){
  if(window.tnFeatureAllowed?.('routes')===false)return;
  if(state.routeBuilding)return;
  if(state.routeBuildKey!==routeBuildKey())invalidateBuiltRoute();
  if(!state.routeStops?.length){await optimizeAndDrawRoute();if(!state.routeStops?.length)return}
  const saved=readNavChoice(localStorage.getItem(NAV_CHOICE_KEY));
  if(saved){runNavChoice(saved);return}
  openNavChoice(true);
}
function runNavChoice(choice){
  if(choice==='google'){openGoogleRouteBlocks();return}
  if(choice==='apple'){openAppleRoute();return}
  beginInAppNav();
}
function ensureNavControls(){
  const actions=document.querySelector('#navBar .navBarActions');
  if(actions&&!$('navPause')){
    const pause=document.createElement('button');
    pause.type='button';
    pause.id='navPause';
    pause.textContent='Pause';
    actions.insertBefore(pause, $('navEnd'));
  }
  const shell=document.querySelector('.mapShell');
  if(shell&&!$('navCompass')){
    const compass=document.createElement('button');
    compass.type='button';
    compass.id='navCompass';
    compass.className='navCompass';
    compass.setAttribute('aria-label','Heading up');
    compass.innerHTML='<span class="navCompassFace" aria-hidden="true"><b class="navCompassDial">N</b></span>';
    shell.appendChild(compass);
  }
  const pauseBtn=$('navPause');
  if(pauseBtn&&!pauseBtn.dataset.bound){pauseBtn.dataset.bound='1';pauseBtn.onclick=toggleNavPause}
  const compass=$('navCompass');
  if(compass&&!compass.dataset.bound){compass.dataset.bound='1';compass.onclick=()=>{ if(state.navigating) recenterNav(); }}
}
function syncPauseButton(){
  const btn=$('navPause'); if(!btn)return;
  const paused=Boolean(state.navPaused);
  btn.textContent=paused?'Resume':'Pause';
  btn.setAttribute('aria-pressed', paused?'true':'false');
}
function enterNavPresentation(){
  // Fullscreen guidance remains reachable while the planning sheet is hidden.
  document.querySelector('.mapShell')?.append($('navBar'));
  document.documentElement.classList.add('isNavigating');
  document.documentElement.classList.remove('isNavPaused');
  const root=document.documentElement;
  const call=root.requestFullscreen||root.webkitRequestFullscreen;
  state.navFullscreenOn=false;
  if(typeof call==='function'){
    Promise.resolve(call.call(root)).then(()=>{state.navFullscreenOn=true;fitNavMap()}).catch(()=>fitNavMap());
  }else fitNavMap();
}
function leaveNavPresentation(paused){
  $('listSheet')?.querySelector('.listSheetBody')?.prepend($('navBar'));
  state.navFullscreenExitIntent=true;
  const active=document.fullscreenElement||document.webkitFullscreenElement;
  const exit=document.exitFullscreen||document.webkitExitFullscreen;
  if(active&&exit) Promise.resolve(exit.call(document)).catch(()=>{});
  else state.navFullscreenExitIntent=false;
  if(paused){
    document.documentElement.classList.remove('isNavigating');
    document.documentElement.classList.add('isNavPaused');
    $('routeTray')?.classList.remove('isNavHidden');
  }else{
    document.documentElement.classList.remove('isNavigating','isNavPaused');
  }
  setMapHeading(state.map, 0);
  requestAnimationFrame(()=>state.map?.invalidateSize({animate:false}));
}
function fitNavMap(){
  requestAnimationFrame(()=>{
    state.map?.invalidateSize({animate:false});
    const here=state.navDisplay||state.currentLocation;
    if(here&&state.navigating&&state.navFollow&&!state.navPaused) flyNavCamera(here, navZoomFor(state.routeMode, state.navSpeed||0));
  });
}
function onNavFullscreenChange(){
  const active=document.fullscreenElement||document.webkitFullscreenElement;
  if(active||state.navFullscreenExitIntent||!state.navFullscreenOn) {state.navFullscreenExitIntent=false;return}
  if(state.navigating&&!state.navPaused) pauseNavigation();
}
function listenNavCompass(){
  if(state.navOrientOn) return;
  state.navOrientOn=true;
  state.navOrientHandler=onNavOrientation;
  window.addEventListener('deviceorientationabsolute', state.navOrientHandler, true);
  window.addEventListener('deviceorientation', state.navOrientHandler, true);
}
function stopNavCompass(){
  if(!state.navOrientHandler) return;
  window.removeEventListener('deviceorientationabsolute', state.navOrientHandler, true);
  window.removeEventListener('deviceorientation', state.navOrientHandler, true);
  state.navOrientHandler=null;state.navOrientOn=false;
}
function onNavOrientation(event){
  if(!state.navigating||state.navPaused) return;
  const angle=Number(window.screen?.orientation?.angle??window.orientation??0)||0;
  const heading=compassHeadingFromOrientation(event, angle);
  if(Number.isFinite(heading)) state.navCompass=heading;
}
function routeAheadBearing(sample){
  if(!sample) return null;
  const line=state.navLine;
  if(line&&line.length>=2){
    const snap=snapToRoute(sample, line, 80);
    const from={lat:snap.lat,lng:snap.lng};
    const ahead=pointAlong(line, (snap.along||0)+30);
    if(ahead&&metersBetween(from, ahead)>3) return bearingDegrees(from, ahead);
  }
  const stop=state.routeStops?.[state.navIndex];
  if(stop&&isCoords(stop)&&metersBetween(sample, stop)>3) return bearingDegrees(sample, {lat:Number(stop.lat),lng:Number(stop.lng)});
  return null;
}
function travelHeadingTarget(sample){
  return chooseTravelHeading({
    gpsHeading:state.navGpsHeading,
    speedMps:state.navGpsSpeed??state.navSpeed??0,
    compassHeading:state.navCompass,
    segmentBearing:routeAheadBearing(sample)
  });
}
function lockNavHeading(sample, now, immediate){
  if(!state.map||!state.navigating||state.navPaused||!state.navFollow) return;
  const target=travelHeadingTarget(sample);
  const dt=state.navBearingAt?(now-state.navBearingAt)/1000:0.016;
  state.navBearingAt=now;
  const next=immediate||!Number.isFinite(state.navUp)?(target??state.navUp??0):smoothBearing(state.navUp, target??state.navUp, reducedMotion()?1:dt);
  state.navUp=next;
  setMapHeading(state.map, next);
  state.navUpApplied=next;
  const dial=document.querySelector('.navCompassDial');
  if(dial){
    const rounded=Math.round(next);
    if(dial.dataset.up!==String(rounded)){dial.dataset.up=String(rounded);dial.style.transform=`rotate(${-rounded}deg)`}
  }
}
function toggleNavPause(){
  if(!state.navigating) return;
  if(state.navPaused) resumeNavigation();
  else pauseNavigation();
}
function pauseNavigation(){
  if(!state.navigating||state.navPaused) return;
  state.navPaused=true;
  state.navFollow=false;
  state.navUp=0;
  leaveNavPresentation(true);
  syncPauseButton();
  syncRecenterButton();
}
function resumeNavigation(){
  if(!state.navigating) return;
  state.navPaused=false;
  state.navFollow=true;
  state.navUp=null;
  $('routeTray')?.classList.add('isNavHidden');
  enterNavPresentation();
  syncPauseButton();
  syncRecenterButton();
  const here=state.navDisplay||state.currentLocation;
  if(here){lockNavHeading(here, performance.now(), true);flyNavCamera(here, navZoomFor(state.routeMode, state.navSpeed||0))}
}
function beginInAppNav(){
  if(!state.routeStops?.length){toast('Build a route first.');return}
  if(!navigator.geolocation){$('routeTrayNote').textContent='This browser cannot share location. Use Google Maps for turn-by-turn.';toast('Location is unavailable. Open Google Maps instead.');return}
  requestCompassPermission().then(status=>{ if(status==='denied') return; listenNavCompass(); });
  if(state.navWatch!=null)navigator.geolocation.clearWatch(state.navWatch);
  state.navigating=true;state.navPaused=false;state.navIndex=0;state.navFollow=true;state.navPrompted='';state.navLegStop='';state.navLegFrom=null;state.navLegGeometry=null;
  state.navFilter=createGpsFilter({deadbandMeters:0.8,maxSpeed:55,maxGain:0.9,accuracyDeadband:0.08});state.navInterp=createInterpolator();state.navGate=createRerouteGate();state.navTray=createReadoutThrottle();
  state.navLine=null;state.navSteps=[];state.navStepIndex=-1;state.navZoomed=false;state.navPanUntil=0;state.navPinKey='';state.navOffShown=false;
  state.navRouted=false;state.navAlong=0;state.navAheadBucket=-1;state.navSpeed=0;state.navGpsSpeed=null;state.navGpsHeading=null;state.navCompass=null;state.navUp=null;state.navUpApplied=null;state.navBearingAt=0;state.navSpeedFix=null;state.navZoom=null;state.navZoomWant=null;
  if(state.routeLine){state.map?.removeLayer(state.routeLine);state.routeLine=null}
  if(state.userMarker){state.userMarker.remove();state.userMarker=null}
  ensureNavControls();
  const modeLabel=state.routeMode==='walking'?'Walk':'Drive';
  const modeEl=$('navMode'); if(modeEl) modeEl.textContent=modeLabel;
  const bar=$('navBar'); if(bar){bar.dataset.mode=modeLabel;bar.classList.remove('hidden')}
  $('routeTray')?.classList.add('isNavHidden');
  $('navAppleLeg').classList.toggle('hidden', !isAppleDevice(navigator.userAgent, navigator.maxTouchPoints));
  enterNavPresentation();
  syncRecenterButton();
  syncPauseButton();
  writeNavText('Next stop', 'Waiting for location…');
  showNavVisuals();
  if(state.currentLocation) flyNavCamera(state.currentLocation, navZoomFor(state.routeMode, 0));
  startNavLoop();
  holdWakeLock();
  document.addEventListener('visibilitychange', onNavVisibility);
  state.navWatch=navigator.geolocation.watchPosition(onNavPosition, onNavError, {enableHighAccuracy:true, maximumAge:0, timeout:10000});
}
function endNavigation(message){
  if(state.navWatch!=null&&navigator.geolocation)navigator.geolocation.clearWatch(state.navWatch);
  state.navWatch=null;state.navigating=false;state.navPaused=false;state.navLegGeometry=null;state.navLine=null;
  state.navUp=null;state.navGpsHeading=null;state.navCompass=null;
  cancelAnimationFrame(state.navFrame);clearTimeout(state.navPinTimer);state.navPinTimer=0;
  document.removeEventListener('visibilitychange', onNavVisibility);
  stopNavCompass();
  releaseScreenWakeLock(state.navWake);state.navWake=null;
  clearNavLayers();
  restoreNavZoomSnap();
  leaveNavPresentation(false);
  setMapHeading(state.map, 0);
  $('navBar')?.classList.add('hidden');
  $('routeTray')?.classList.remove('isNavHidden');
  if(state.routeStops?.length) drawRoutePreview(false);
  if(message)toast(message);
}
function onNavVisibility(){if(document.visibilityState==='visible'&&state.navigating)holdWakeLock()}
async function holdWakeLock(){state.navWake=await acquireScreenWakeLock(navigator)}
function onNavError(err){
  const denied=err&&err.code===1;
  const message=denied?'Location is blocked. Allow it in the browser, or use Google Maps.':'Location is unavailable right now. You can still open Google Maps.';
  if($('navMeta'))$('navMeta').textContent=message;
  if($('routeTrayNote'))$('routeTrayNote').textContent=message;
  toast(message);
}
function onNavPosition(pos){
  if(!state.navigating||!state.map)return;
  const now=performance.now();
  const heading=pos.coords?.heading;
  const speed=pos.coords?.speed;
  if(Number.isFinite(speed)&&speed>=0) state.navGpsSpeed=speed;
  if(Number.isFinite(heading)&&(state.navGpsSpeed??state.navSpeed??0)>=0.9) state.navGpsHeading=heading;
  else if((state.navGpsSpeed??state.navSpeed??0)<0.6) state.navGpsHeading=null;
  const filtered=state.navFilter.push({lat:pos.coords.latitude,lng:pos.coords.longitude,accuracy:pos.coords.accuracy,heading:Number.isFinite(heading)?heading:null}, now);
  if(!filtered)return;
  const stop=state.routeStops[state.navIndex];
  if(!stop){endNavigation('Route complete.');return}
  const snap=snapToRoute(filtered, state.navLine, 22);
  const display={lat:snap.snapped?snap.lat:filtered.lat,lng:snap.snapped?snap.lng:filtered.lng,heading:filtered.heading,accuracy:filtered.accuracy,interval:filtered.interval};
  state.currentLocation=display;
  noteNavSpeed(filtered, now);
  if(state.navPaused){state.navInterp.setTarget(display, now, reducedMotion());return}
  lockNavHeading(display, now, !state.navZoomed);
  state.navInterp.setTarget(display, now, reducedMotion());
  if(state.navLegStop!==stop.id){state.navLegStop=stop.id;state.navLine=null;loadNavLeg(display, stop)}
  else publishProgress(stop, display, snap, false);
  const off=snap.snapped||!Number.isFinite(snap.distance)?0:snap.distance;
  if((state.navLine?.length||0)>=2 && state.navGate.consider(off, now)) loadNavLeg(display, stop);
  const meters=metersBetween(filtered, stop);
  if(arrivedAtStop(filtered, stop)&&state.navPrompted!==stop.id){
    state.navPrompted=stop.id;openDoorSheet(stop.id);
    toast(`You're within ${ARRIVAL_METERS} m. Mark this door, and the route moves to the next stop.`);
  }else if(state.navPrompted===stop.id&&meters>ARRIVAL_METERS+25)state.navPrompted='';
  maybeNavZoom(display);
  maybeEaseNavZoom(display);
}
let navLegToken=0;
async function loadNavLeg(here, stop){
  const token=++navLegToken;
  const meters=metersBetween(here, stop);
  state.navLegMeters=meters;state.navLegSeconds=etaSeconds(meters, state.routeMode);
  state.navRouted=false;state.navLine=null;state.navAheadBucket=-1;
  showNavVisuals();
  paintAhead(0, true);
  if(isCoords(stop)) placeNavStop(stop);
  publishProgress(stop, here, snapToRoute(here, state.navLine, 22), true);
  try{
    const r=await fetch('/api/route',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({profile:osrmProfile(state.routeMode),service:'route',steps:true,coordinates:[{lat:here.lat,lng:here.lng},{lat:Number(stop.lat),lng:Number(stop.lng)}]})});
    const data=await r.json();
    if(!r.ok||token!==navLegToken||!state.navigating)return;
    const line=lineLatLngs(data.geometry);
    if(line.length>=2){
      state.navLine=line;state.navLegGeometry=data.geometry;state.navRouted=true;state.navAheadBucket=-1;
      state.navLegMeters=Number(data.distance)||meters;
      state.navLegSeconds=Number(data.duration)||state.navLegSeconds;
      state.navSteps=normalizeSteps(data.steps);state.navStepIndex=-1;
      const snap=snapToRoute(here, line, 22);
      paintAhead(snap.snapped?snap.along:0, true);
      publishProgress(stop, here, snap, true);
    }
  }catch{/* leave the forward line off until a road route arrives */}
}
function publishProgress(stop, place, snap, immediate){
  const total=snap?.total>1?snap.total:(state.navLegMeters||metersBetween(place, stop));
  const along=snap?.snapped?snap.along:0;
  const left=snap?.snapped?Math.max(0, total-along):metersBetween(place, stop);
  const seconds=total>1&&state.navLegSeconds?state.navLegSeconds*(left/Math.max(total,1)):etaSeconds(left, state.routeMode);
  const step=snap?.snapped?activeStep(state.navSteps, along):null;
  if(step&&step.index!==state.navStepIndex) immediate=true;
  if(step) state.navStepIndex=step.index;
  const offRoute=Boolean(snap&&!snap.snapped&&Number.isFinite(snap.distance)&&snap.distance>40);
  const title=offRoute?'Rejoining the route':(step?maneuverText(step.step):`Continue to ${stop.address||'the stop'}`);
  const mode=state.routeMode==='walking'?'walk':'drive';
  const meta=`${fmtDistance(left/1609.344)} · ${fmtDuration(seconds)} ${mode} · ${state.navIndex+1} of ${state.routeStops.length}`;
  const changedOff=offRoute!==state.navOffShown;
  state.navOffShown=offRoute;
  const write=state.navTray.push(title, meta, performance.now(), immediate||changedOff);
  if(write) writeNavText(write.title, write.meta);
}
function writeNavText(title, meta){
  const titleEl=$('navTitle'), metaEl=$('navMeta');
  if(titleEl&&titleEl.textContent!==title) titleEl.textContent=title;
  if(metaEl&&metaEl.textContent!==meta) metaEl.textContent=meta;
}
function showNavVisuals(){
  if(!state.map)return;
  if(!state.map.getPane('navPane')){
    const pane=state.map.createPane('navPane', state.map._tnRotatePane||state.map.getPane('overlayPane'));
    pane.style.zIndex='450';
    pane.style.pointerEvents='none';
  }
  if(!state.navRenderer) state.navRenderer=L.canvas({pane:'navPane'});
  const lineOpts=(color, weight, opacity)=>({pane:'navPane', renderer:state.navRenderer, interactive:false, color, weight, opacity, lineCap:'round', lineJoin:'round'});
  if(!state.navArrow){
    const icon=L.divIcon({className:'navArrowIcon', html:'<div class="navArrow"></div>', iconSize:[34,34], iconAnchor:[17,17]});
    state.navArrow=L.marker([HOME_BASE.lat, HOME_BASE.lng], {icon, interactive:false, keyboard:false, zIndexOffset:2000});
  }
  if(!state.navAccuracy) state.navAccuracy=L.circle([HOME_BASE.lat, HOME_BASE.lng], {radius:18, pane:'navPane', renderer:state.navRenderer, interactive:false, color:'#1e6bff', weight:1, fillColor:'#1e6bff', fillOpacity:.12});
  if(!state.navCasing) state.navCasing=L.polyline([], lineOpts('#0c1424', 11, .55));
  if(!state.navTraveled) state.navTraveled=L.polyline([], lineOpts('#5d6d7e', 5, .72));
  if(!state.navLegLine) state.navLegLine=L.polyline([], lineOpts('#1e6bff', 6, .98));
  if(!state.navStop){
    const icon=L.divIcon({className:'navStopIcon', html:'<div class="navStop"><span>1</span></div>', iconSize:[34,34], iconAnchor:[17,17]});
    state.navStop=L.marker([HOME_BASE.lat, HOME_BASE.lng], {icon, interactive:false, keyboard:false, zIndexOffset:1500});
  }
  if(state.currentLocation){
    state.navArrow.setLatLng([state.currentLocation.lat, state.currentLocation.lng]);
    state.navAccuracy.setLatLng([state.currentLocation.lat, state.currentLocation.lng]);
  }
  [state.navCasing, state.navTraveled, state.navLegLine, state.navAccuracy, state.navArrow].forEach(layer=>{
    if(layer&&!state.map.hasLayer(layer)) layer.addTo(state.map);
  });
}
function placeNavStop(stop){
  if(!state.navStop||!isCoords(stop))return;
  state.navStop.setLatLng([Number(stop.lat), Number(stop.lng)]);
  if(!state.map.hasLayer(state.navStop)) state.navStop.addTo(state.map);
  const label=String((state.navIndex||0)+1);
  const el=state.navStop.getElement()?.querySelector('span');
  if(el&&el.textContent!==label) el.textContent=label;
}
function paintAhead(along, force){
  if(!state.navCasing||!state.navLegLine||!state.navTraveled)return;
  if(!state.navRouted||!state.navLine||state.navLine.length<2){
    if(force||state.navAheadBucket!==-2){
      state.navAheadBucket=-2;
      state.navCasing.setLatLngs([]);
      state.navLegLine.setLatLngs([]);
      state.navTraveled.setLatLngs([]);
    }
    return;
  }
  const bucket=Math.round((Number(along)||0)/14);
  if(!force&&bucket===state.navAheadBucket)return;
  state.navAheadBucket=bucket;
  state.navAlong=Number(along)||0;
  const parts=splitRoute(state.navLine, state.navAlong);
  const ahead=parts.ahead.map(point=>[point.lat, point.lng]);
  const traveled=parts.traveled.length>1?parts.traveled.map(point=>[point.lat, point.lng]):[];
  state.navCasing.setLatLngs(ahead);
  state.navLegLine.setLatLngs(ahead);
  state.navTraveled.setLatLngs(traveled);
}
function paintNavFrame(sample){
  if(!sample||!state.navArrow)return;
  state.navArrow.setLatLng([sample.lat, sample.lng]);
  const arrow=state.navArrow.getElement()?.querySelector('.navArrow');
  if(arrow){
    const heading=Math.round(arrowRotationDegrees(sample.heading, state.navUp));
    if(arrow.dataset.h!==String(heading)){arrow.dataset.h=String(heading);arrow.style.transform=`rotate(${heading}deg)`}
  }
  state.navDisplay=sample;
  const now=performance.now();
  if(state.navAccuracy&&now-(state.navAccuracyAt||0)>240){
    state.navAccuracyAt=now;
    state.navAccuracy.setLatLng([sample.lat, sample.lng]);
    const acc=Number(state.currentLocation?.accuracy);
    if(Number.isFinite(acc)) state.navAccuracy.setRadius(Math.max(8, Math.min(80, acc)));
  }
  if(state.navRouted&&now-(state.navLinePaintAt||0)>220){
    state.navLinePaintAt=now;
    const snap=snapToRoute(sample, state.navLine, 80);
    paintAhead(snap.along||0, false);
  }
}
function startNavLoop(){
  cancelAnimationFrame(state.navFrame);
  const loop=(now)=>{
    if(!state.navigating)return;
    const sample=state.navInterp?.sample(now);
    if(sample){
      if(!state.navPaused&&state.navFollow) lockNavHeading(sample, now, false);
      paintNavFrame(sample);
      if(state.navFollow&&!state.navPaused) easeFollow(sample);
      if(now-(state.navReadoutAt||0)>200){
        state.navReadoutAt=now;
        const stop=state.routeStops[state.navIndex];
        if(stop) publishProgress(stop, sample, snapToRoute(sample, state.navLine, 80), false);
      }
    }
    const flushed=state.navTray?.flush(now);
    if(flushed) writeNavText(flushed.title, flushed.meta);
    state.navFrame=requestAnimationFrame(loop);
  };
  state.navFrame=requestAnimationFrame(loop);
}
function navCameraLatLng(sample, zoom){
  const heading=Number.isFinite(state.navUp)?state.navUp:(Number.isFinite(sample.heading)?sample.heading:routeAheadBearing(sample));
  const aimed=Number.isFinite(heading)?heading:0;
  const pixels=navLookaheadPixels(state.routeMode, aimed, state.map.getSize().y);
  const projected=state.map.project([sample.lat, sample.lng], zoom);
  const shifted=offsetCameraPoint(projected, aimed, pixels);
  return state.map.unproject([shifted.x, shifted.y], zoom);
}
function engageNavZoomSnap(){
  if(!state.map||state.navZoomSnap!=null)return;
  state.navZoomSnap=state.map.options.zoomSnap??1;
  state.map.options.zoomSnap=0.5;
}
function restoreNavZoomSnap(){
  if(!state.map||state.navZoomSnap==null)return;
  state.map.options.zoomSnap=state.navZoomSnap;
  state.navZoomSnap=null;
}
function flyNavCamera(sample, zoom){
  if(!state.map||!sample||!Number.isFinite(sample.lat)||!Number.isFinite(sample.lng))return;
  engageNavZoomSnap();
  const center=navCameraLatLng(sample, zoom);
  state.navZoom=zoom;
  state.navZoomed=true;
  state.navZoomWant=zoom;
  const animate=!reducedMotion();
  const duration=animate?1.05:0;
  const token=++state.navFlyToken;
  state.navAutoMove=true;
  state.navPanUntil=performance.now()+duration*1000+160;
  const release=()=>{if(token===state.navFlyToken)state.navAutoMove=false};
  state.map.once('moveend', release);
  setTimeout(release, duration*1000+500);
  if(animate) state.map.flyTo([center.lat, center.lng], zoom, {duration, easeLinearity:0.25});
  else {state.map.setView([center.lat, center.lng], zoom, {animate:false}); release();}
}
function easeFollow(sample){
  if(!state.map||!state.navZoomed||state.navPaused)return;
  const now=performance.now();
  if(state.navPanUntil&&now<state.navPanUntil)return;
  const zoom=state.navZoom??navZoomFor(state.routeMode, state.navSpeed||0);
  if(Math.abs((state.map.getZoom()||0)-zoom)>0.4){flyNavCamera(sample, zoom);return}
  const center=navCameraLatLng(sample, zoom);
  if(metersBetween({lat:state.map.getCenter().lat,lng:state.map.getCenter().lng}, center)<0.4)return;
  state.navAutoMove=true;
  state.map.setView([center.lat, center.lng], zoom, {animate:false});
  state.navAutoMove=false;
}
function noteNavSpeed(fix, now){
  if(state.navSpeedFix){
    const dt=(now-(state.navSpeedAt||now))/1000;
    if(dt>0.3&&dt<5){
      const pace=metersBetween(state.navSpeedFix, fix)/dt;
      state.navSpeed=state.navSpeed?state.navSpeed*0.65+pace*0.35:pace;
    }
  }
  state.navSpeedFix=fix;
  state.navSpeedAt=now;
}
function maybeNavZoom(sample){
  if(state.navZoomed||!state.navFollow||!state.map)return;
  flyNavCamera(sample, navZoomFor(state.routeMode, state.navSpeed||0));
}
function maybeEaseNavZoom(sample){
  if(!state.navZoomed||!state.navFollow||!state.map)return;
  const zoom=navZoomFor(state.routeMode, state.navSpeed||0);
  if(Math.abs(zoom-(state.navZoom??zoom))<0.01){state.navZoomWant=zoom;return}
  const now=performance.now();
  if(state.navZoomWant!==zoom){state.navZoomWant=zoom;state.navZoomWantAt=now;return}
  if(now-(state.navZoomWantAt||0)<4000)return;
  if(state.navPanUntil&&now<state.navPanUntil)return;
  flyNavCamera(sample, zoom);
}
function clearNavLayers(){
  [state.navArrow,state.navAccuracy,state.navCasing,state.navTraveled,state.navLegLine,state.navStop].forEach(layer=>{try{layer?.remove()}catch{}});
  state.navArrow=null;state.navAccuracy=null;state.navCasing=null;state.navTraveled=null;state.navLegLine=null;state.navStop=null;state.navRenderer=null;
}
function drawNavOverlay(){
  if(!state.map||!state.navigating)return;
  showNavVisuals();
  const here=state.navDisplay||state.currentLocation;
  if(here) paintNavFrame({lat:here.lat,lng:here.lng,heading:here.heading||0});
  const stop=state.routeStops[state.navIndex];
  if(stop) placeNavStop(stop);
  if(state.navRouted) paintAhead(state.navAlong||0, true);
}
function syncRecenterButton(){
  const btn=$('navRecenter');if(!btn)return;
  const unlocked=Boolean(state.navigating&&!state.navFollow);
  btn.classList.remove('hidden');
  btn.textContent='Re-center';
  btn.classList.toggle('isOn', unlocked);
}
function recenterNav(){
  if(!state.navigating)return;
  if(state.navPaused) resumeNavigation();
  state.navFollow=true;syncRecenterButton();
  const here=state.navDisplay||state.currentLocation;
  if(here) lockNavHeading(here, performance.now(), true);
  if(!here||!state.map)return;
  flyNavCamera(here, navZoomFor(state.routeMode, state.navSpeed||0));
}
function openExternalLeg(kind){
  const stop=state.routeStops[state.navIndex];
  if(!stop){toast('No stop left on this route.');return}
  if(kind==='apple'){openAppleRoute([stop]);return}
  window.open(googleDirectionsUrl(state.currentLocation, stop, state.routeMode),'_blank','noopener');
}
function advanceNavStop(){
  if(!state.navigating)return;
  state.navIndex+=1;state.navPrompted='';state.navLegStop='';state.navLegGeometry=null;state.navLine=null;state.navRouted=false;state.navAheadBucket=-1;state.navSteps=[];state.navStepIndex=-1;
  const stop=state.routeStops[state.navIndex];
  if(!stop){endNavigation('Route complete.');return}
  closeDoorSheet();
  toast(`Next stop · ${stop.address}`);
  if(state.currentLocation){state.navLegStop=stop.id;loadNavLeg(state.currentLocation, stop)}
}
function maybeAdvanceNav(id){
  if(!state.navigating)return;
  const stop=state.routeStops[state.navIndex];
  if(stop&&stop.id===id)advanceNavStop();
}

function haversine(lat1,lon1,lat2,lon2){const R=3958.7613,rad=Math.PI/180;const dLat=(lat2-lat1)*rad,dLon=(lon2-lon1)*rad;const a=Math.sin(dLat/2)**2+Math.cos(lat1*rad)*Math.cos(lat2*rad)*Math.sin(dLon/2)**2;return 2*R*Math.asin(Math.sqrt(a))}

function exportLeads(){
  const rows=state.leads.map(l=>({id:l.id,name:l.name,address:l.address,city:l.city,state:l.state,zip:l.zip,status:leadStatus(l),assigned_rep:leadOwnerName(l),lat:l.lat??'',lng:l.lng??'',year_built:l.year_built??l.yearBuilt??'',roof_age_years:l.roof_age_years??'',roof_age_verified:l.roof_age_verified??'',notes:l.notes||''}));
  const head=Object.keys(rows[0]||{});const csv=[head.join(','),...rows.map(r=>head.map(k=>`"${String(r[k]??'').replaceAll('"','""')}"`).join(','))].join('\n');
  const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));a.download='true-north-sales-map-export.csv';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}

function toast(message, ms=2600){
  const el=$('toast'); if(!el)return;
  // A live echo of the save we just made must not cover the Undo button.
  if(state.doorUndo) return;
  $('toastText').textContent=message;
  $('toastActions').classList.add('hidden');
  state.doorUndo=null;
  el.classList.add('show');
  clearTimeout(toast._t);
  toast._t=setTimeout(()=>{el.classList.remove('show'); syncListOverlay();}, ms);
  syncListOverlay();
}

function startRealtime(){
  if(state.mode!=='cloud'||!state.supabase||state.realtimeChannel)return;
  state.realtimeChannel=state.supabase.channel('tnrc-field-live')
    .on('postgres_changes',{event:'*',schema:'public',table:'leads'},payload=>{
      const idx=state.leads.findIndex(l=>l.id===payload.old?.id||l.id===payload.new?.id);
      if(payload.eventType==='DELETE'){if(idx>=0)state.leads.splice(idx,1);}
      else {const incoming=normalizeLead(payload.new);if(idx>=0)state.leads[idx]={...state.leads[idx],...incoming};else state.leads.push(incoming);}
      renderAll(); toast('Live lead update received');
    })
    .on('postgres_changes',{event:'*',schema:'public',table:'appointments'},payload=>{
      const idx=state.appointments.findIndex(a=>a.id===payload.old?.id||a.id===payload.new?.id);
      if(payload.eventType==='DELETE'){if(idx>=0)state.appointments.splice(idx,1);}
      else if(idx>=0)state.appointments[idx]={...state.appointments[idx],...payload.new}; else state.appointments.push(payload.new);
      renderAll(); toast('Appointment board updated');
    })
    .on('postgres_changes',{event:'INSERT',schema:'public',table:'lead_activity'},payload=>{state.activities.unshift(payload.new);state.activities=state.activities.slice(0,3000);renderStats();renderTeam();})
    .subscribe();
}

function closeModal(){document.querySelectorAll('.modalOverlay').forEach(x=>x.classList.add('hidden'))}

document.addEventListener('keydown',e=>{
  if(e.ctrlKey||e.metaKey||e.altKey||document.querySelector('dialog[open], .pageTour')) return;
  if(e.key!=='Escape'&&document.querySelector('.modalOverlay:not(.hidden), .drawer:not(.hidden), .doorSheet.open'))return;
  if(['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName)) return;
  if(e.key==='/'){e.preventDefault();$('search').focus();}
  else if(e.key.toLowerCase()==='n') nextBest();
  else if(e.key.toLowerCase()==='r') openRoutePanel();
  else if(e.key.toLowerCase()==='l') locate();
  else if(e.key==='Escape'){closeDoorSheet();closeDrawer();closeRoutePanel();$('adminModal').classList.add('hidden');$('appointmentModal').classList.add('hidden');}
});

if(new URLSearchParams(location.search).get('navsim')==='1'){
  window.__tnNavDebug=()=>({follow:state.navFollow,paused:!!state.navPaused,up:state.navUp,gpsH:state.navGpsHeading,gpsS:state.navGpsSpeed,lat:state.currentLocation?.lat,lng:state.currentLocation?.lng,along:state.navAlong,zoom:state.map?.getZoom?.(),speed:state.navSpeed});
  window.__tnNavSim=(detail={})=>{
    const wait=()=>{
      if(!state.map){setTimeout(wait, 40);return}
      state.routeMode=detail.mode==='walking'?'walking':'driving';
      state.routeStops=(detail.stops||[]).map(stop=>({...stop, lat:Number(stop.lat), lng:Number(stop.lng)}));
      if(detail.start) state.currentLocation={lat:Number(detail.start.lat), lng:Number(detail.start.lng), heading:Number(detail.start.heading)||0};
      beginInAppNav();
    };
    wait();
  };
}
boot();
